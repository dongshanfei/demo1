var gulp = require('gulp');
var sass = require("gulp-sass");
var autoprefixer = require('gulp-autoprefixer');
var clear = require('gulp-clean-css');
var maps = require('gulp-sourcemaps');
var connect = require('gulp-connect');

gulp.task('sass',function(){
	gulp.src('./scss/*')
		.pipe(maps.init())
		.pipe(sass().on('error',sass.logError))
		.pipe(autoprefixer({
			browsers:['last 4 versions','Android >= 4.0']}))
		.pipe(clear())
		.pipe(maps.write('/'))
		.pipe(gulp.dest('./css'))
		.pipe(connect.reload());

});

gulp.task('sassWatch',function(){
	gulp.watch('./scss/*.scss',['sass']);
});

gulp.task('connect',function(){
	connect.server({
		livereload:true
	})
})

gulp.task('default',['sassWatch','connect']);
