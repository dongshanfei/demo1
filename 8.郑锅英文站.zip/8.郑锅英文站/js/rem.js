 function bodyScale(){
        var devicewidth=document.documentElement.clientWidth;
        var scale=devicewidth/640;
        document.body.style.zoom=scale;
    }
    window.onload=window.onresize=function(){
        bodyScale();
    }
   
    (function(){
            function w() {
                var r = document.documentElement;
                var a = r.getBoundingClientRect().width;
                if (a > 768){
                    a = 768
                } 
                rem = a / 7.68
                r.style.fontSize = rem + "px"
            }
            var t;
            w();
            window.addEventListener("resize", function() {
                clearTimeout(t);
                t = setTimeout(w, 100);
            }, false);
    });