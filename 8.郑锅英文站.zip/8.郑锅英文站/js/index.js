$(function(){
	//首页banner视频静音
	var myVideo = document.getElementById("myVideo");
		if(myVideo){
			myVideo.addEventListener("canplay",function(){
				myVideo.muted = true;
			})
		} 
	

		
	//页面右上角放大镜手机端是页面，屏幕端是input框
	//此处为什么不能用resize：只有拉动屏幕才能出发事件
	// var oot;
    $(window).on("resize",function(){
    		isHref()
     });
    function isHref(){
        var widthD = $(document).width();
        if(widthD>769){
            $(".search .icon-sousuo_sousuo").on("click",function(e){
                $(".searchbox").fadeIn();
                $(document).one('click',function(){
                    $('.searchbox').fadeOut();
                    $("#search").val("");
                })
                e.stopPropagation();
            });
            $(".searchbox").click(function(e){
                e.stopPropagation();
            });
            //这是主页视频部分大于769显示部分
			function timeMsg(){
				var t =setTimeout(function(){
					$('.bannerimg').hide();
					$('#myVideo').show();
					$("#myVideo")[0].play();
				},4000)
			}
			timeMsg();

        }
        else{
            $(".search .icon-sousuo_sousuo").on("click",function(){
                    // location.href='search.html';
                    location.href='http://192.168.1.43:90/searchs/';
                    e.stopPropagation();
            })
            //这是主页视频<768不显示
            $('#myVideo').hide();
        }
    }
     isHref()
	//lang
	$(".langToggle").click(function(e){
		$(".triangle").toggleClass("clicked");
		$(".langBox").slideToggle(300);
		e.stopPropagation();
		$(document).one("click",function(){
			$(".triangle").removeClass("clicked");
			$(".langBox").stop().slideUp();
		})	
	})
	$(".asmeIcon li").hover(function(){
		$(this).find("img").hide();
		$(this).addClass("hovering");
	},function(){
		$(this).find("img").show();
		$(this).removeClass("hovering");
	})
	//mobile nav
	$(".navMobile").click(function(){
			$(".bg_mask").stop().fadeIn();
			$("nav").show();
			$("nav ul").animate({right:"0"},500);
			$("nav ul li").css("backgroundColor",("#fff"));
			$("body").bind("touchmove",function(e){
				e.preventDefault();
			})
	})
	$(".bg_mask").click(function(){
			$(this).stop().fadeOut();
			// $("nav").fadeOut();
			$("nav ul").animate({right:"-50%"},500);
			$(".wechat_share").hide();
			$("body").unbind("touchmove");
	})

	//这是页面下面的三个方形+tag切换
	$("#accordion li").click(function(e) {
        var e = e || event;
        var index = $(this).index()
         var div = $(e.target).siblings("ul").slideToggle();
         $("#accordion li .icon").eq(index).toggleClass("xuan")
    });
	$(".icon").click(function(e) {
        var e = e || event;
        e.cancelBubble = true;
        e.stopPropagation();
        e.preventDefault();
        var div = $(e.target).parent("div").siblings("ul").slideToggle();
        $(e.target).toggleClass("xuan");

    });


	//aboutUs section1
	$(".aboutZBG").one("mouseover",function(){
		$(this).find("img").animate({bottom:0},400);
	})
	//aboutUs toggle
	$(".toggleBg").click(function(){
		$(".bar").toggleClass("actived");
		$(".toggleBg").toggleClass("turn");
	})
	//aboutUs engineers Toggle
	$(".engineersIntro ul li").hover(function(){
		$(this).addClass("liHover").siblings('li').removeClass("liHover");
	})    
	
	//封装方法
	var fun = function() {
		if($(window).width()>769){
			$(".lists > div").hover(function(){
					$(this).find('section').stop().animate({bottom:0});
					$(this).find("section").css('backgroundColor','rgba(255,66,0,.9)');
					$(this).find('h3').css('color',"#fff");
					},function(){
						var _this = $(this);
						$(this).find('section').stop().animate({bottom:"-105px"},function(){
							_this.find("section").css('backgroundColor','#fff');
							_this.find('h3').css('color',"#ff4200");
					});	
			})
		}
		else{
			$(".lists > div").on(function(){
					$(this).find("section").css('backgroundColor','rgba(255,66,0,.9)');
					$(this).find('h3').css('color',"#ff4200");	
				}
			)
		}
	}
	fun();
	$(window).resize(function(){
		fun();
	})

	//solution
	$(".scene").hover(function(){
		$(this).find("section").addClass("hover").stop().animate({bottom:0},400);;
		},function(){
		$(this).find("section").removeClass("hover").stop().animate({bottom:"-173px"},400);	
		})
})

$(function(){
	var mapPoint = [
		    { "top": "90", "left": "240", "name": "Canada" },
		    { "top": "288", "left": "282", "name": "Mexico" },
		    { "top": "188", "left": "320", "name": "America" },
		    { "top": "320", "left": "335", "name": "Nicaragua" },
		    { "top": "454", "left": "420", "name": "Columbia" },
		    { "top": "645", "left": "417", "name": "Argentina" },
		    { "top": "454", "left": "527", "name": "Venezuela" },
		    { "top": "338", "left": "700", "name": "Nigeria" },
		    { "top": "188", "left": "710", "name": "Spain" },
		    { "top": "251", "left": "718", "name": "Algena" },
		    { "top": "153", "left": "744", "name": "France" },
		    { "top": "527", "left": "852", "name": "SouthAfrica" },
		    { "top": "138", "left": "862", "name": "Ukraine" },
		    { "top": "373", "left": "881", "name": "Ethiopia" },
		    { "top": "498", "left": "935", "name": "Madagascar" },
		    { "top": "89", "left": "1053", "name": "Russia" },
		    { "top": "279", "left": "1081", "name": "India" },
		    { "top": "233", "left": "1138", "name": "Bangiadesh" },
		    { "top": "394", "left": "1180", "name": "Malsysia" },
		    { "top": "317", "left": "1189", "name": "Thailand" },
		    { "top": "251", "left": "1202", "name": "Laos" },
		    { "top": "191", "left": "1218", "name": "China" },
		    { "top": "383", "left": "1240", "name": "Indonesia" },
		    { "top": "203", "left": "1293", "name": "Koreaz" },
		    { "top": "537", "left": "1373", "name": "Australia" },
		];
		var len = mapPoint.length;
		for(var i = 0; i < len;i++){
			$("<div class='point-area'><a href='' class='point-dot'></a><p>" + mapPoint[i].name + "<div class='point point-10'></div><div class='point point-70'></div></div>")
			.css({"position":"absolute","top":mapPoint[i].top+"px","left":mapPoint[i].left+"px"})
			.appendTo(".mainMap");
		}
})




/* Add unitCalc
 * by wang
 * 2016-11-28
 */
$(function(){
			$(".calc").css({"height":$(document).height()});
			// /*点击显示计算框*/
			$("#calc").click(function(){
				$(".calc").removeClass("hide");
			})
			$(".calcunit").click(function(){
				$(".calc").removeClass("hide");
				$("#calc").trigger("click");
				return false;
			})
			$(".close").click(function(){
				$(this).parents(".calc").addClass("hide");
				$(".conver_btm li div").html("");
				$(".sourDate").val("");
			})
			// /*tab切换*/
			$(".changelist li").click(function(){
				$(this).addClass("select").siblings("li").removeClass("select");
				var index = $(this).index();
				$(".converterbox").eq(index).show().siblings("div").hide();
			})
			/*点击下拉菜单效果*/
			$(".unit_select").click(function(e){
				$(this).toggleClass("active");
				$(".unitlist").stop().fadeToggle();
				e.stopPropagation();
			})
			$(".changebox").click(function(){
				$(".unitlist").hide();
			})
			$(".sourData").bind("keydown",function(event){
				var e = event.keyCode; 
				if((e === 8 || (e > 45 && e < 58) ||(e >36 && e < 41)|| (e > 95 && e < 106) || e === 110) && (event.shiftKey == 0) ){
					return true;
				}
				else{
					event.returnValue=false;
					return false;
				}
			})
		/**************************************************
		 *热能单位转换
		 **************************************************/
			var Arr_heat = ["KW","MW","BHP","T/Hr","Kgs/Hr","Kcal/Hr","Btu/Hr","Btu/s","Lbs/Hr"];
			var len1 = Arr_heat.length;
			/*生成下拉菜单和目标转换单位*/
			for(var i = 0; i < len1;i++){
				$("<li/>").appendTo(".heatlist ul");
				$(".heatlist ul li").eq(i).html(Arr_heat[i]);
				$("<li><div/><span/></li>").appendTo("#heat_target");
				$("#heat_target li > span").eq(i).html(Arr_heat[i]);
			}
			/*热能单位选择*/
			$("#current_heat ul > li").click(function(){
				$("#current_heat > span").html($(this).text());
				$(".sourData:first").trigger("input");
			})
			var tarDate1 = [];
			function convKw(x){
				tarDate1 = [x,x/1000,x*0.102,x*1.33/1000,x*1.33,x*859.845,x*3412.142,x*0.9478,x*2.866];
			}
			function convMW(x){
				tarDate1 = [x*1000,x,x*102,x*1.3,x*1330,x*859845,x*947.8,x*3412142,x*2866];
			}
			function convBHP(x){
				tarDate1 = [x*9.81,x*9.81/1000,x,x*0.013,x*13.05,x*8434.65,x*33473.11,x*9.298,x*28.66];
			}
			function convTh(x){
				tarDate1 = [x*751.88,x*0.7519,x*76.6,x,x*1000,x*646500,x*2565521,x*712.6,x*2204];
			}
			function convKgs(x){
				tarDate1 = [x*0.75188,x/10e3*0.75188,x*0.0766,x/1000,x,x*646.5,x*2565.521,x*0.7126,x*2.204]
			}
			function convKcal(x){
				tarDate1 = [x/1000*1.163,x/10e5*1.163,x/10e3*1.1856,x/10e5*1.5,x/1000*1.547,x,x*3.968321,x/1000*1.102,x/1000*3.307];
			}
			function convBtuHr(x){
				tarDate1 = [x/10e3*2.931,x/10e6*2.931,x/10e4*2.99,x/10e6*3.9,x/10e3*3.898,x*0.2519958,x,x/10e3*2.778,x/10e3*8.591];
			}
			function convBtu(x){
				tarDate1 = [x*1.055,x*1.055/1000,x*0.1076,x*1.4/1000,x*1.403,x*907.185,x*3599.809,x,x*3.086];
			}
			function convLbs(x){
				tarDate1 = [x*0.3413,x/10e2*0.3413,x*0.03476,x/10e2*0.4536,x*0.4536,x*293.207,x*1163.54,x*0.323,x];
			}
			$(".sourData:first").bind("input",function(){
				var $sourData = $(this).val();
				if($sourData == ""){
					$("#heat_target li > div").html("");
				}
				else{
					$sourData = parseFloat($sourData);
					var $sourUnit = $("#current_heat > span").text();
					var index1 = $.inArray($sourUnit,Arr_heat);
					if(index1 === 0){convKw($sourData)};
					if(index1 === 1){convMW($sourData)};
					if(index1 === 2){convBHP($sourData)};
					if(index1 === 3){convTh($sourData)};
					if(index1 === 4){convKgs($sourData)};
					if(index1 === 5){convKcal($sourData)};
					if(index1 === 6){convBtuHr($sourData)};
					if(index1 === 7){convBtu($sourData)};
					if(index1 === 8){convLbs($sourData)};
					tarDate1 = $.map(tarDate1,function(i){
						if(i > 10e8-1){
							return i.toExponential(2);
						}
						else{
							return i.toFixed(2);
						}
					})
					for(var j = 0;j < len1;j++){
						$("#heat_target li > div").eq(j).html(tarDate1[j]);
					}
				}
			})
		/**************************************************
		 *压力单位转换
		 *************************************************/
		 var Arr_press = ["bar","Mpa","psi","kgf/cm²"];
		 var len2 = Arr_press.length;
		 for(var m = 0;m < len2;m++){
		 	$("<li/>").appendTo(".presslist ul");
				$(".presslist ul li").eq(m).html(Arr_press[m]);
				$("<li><div/><span/></li>").appendTo("#press_target");
				$("#press_target li > span").eq(m).html(Arr_press[m]);
		 }
		 $("#current_press ul > li").click(function(){
				$("#current_press > span").html($(this).text());
				$(".sourData:eq(1)").trigger("input");
			})
		 var tarDate2 = [];
		 function convBar(x){
		 	tarDate2 = [x,x/10,x*14.5,x*1.02];
		 }
		 function convMpa(x){
		 	tarDate2 = [x*10,x,x*145,x*10.2];
		 }
		 function convPsi(x){
		 	tarDate2 = [x*0.06895,x/1000*6.895,x,x*0.0703];
		 }
		 function convKgf(x){
		 	tarDate2 = [x*0.9807,x*0.0981,x*14.2,x];
		 }
		 $(".sourData:eq(1)").bind("input",function(){
				var $sourData = $(this).val();
				if($sourData == ""){
					$("#press_target li > div").html("");
				}
				else{
					var $sourData = parseFloat($sourData);
					var $sourUnit = $("#current_press > span").text();
					var index2 =jQuery.inArray($sourUnit,Arr_press);
					if(index2 === 0){convBar($sourData)};
					if(index2 === 1){convMpa($sourData)};
					if(index2 === 2){convPsi($sourData)};
					if(index2 === 3){convKgf($sourData)};
					tarDate2 = $.map(tarDate2,function(i){
						if(i > 10e8-1){
							return i.toExponential(2);}
						else{
							return i.toFixed(2);
						}
					})
					for(var n = 0;n < len2;n++){
						$("#press_target li > div").eq(n).html(tarDate2[n]);
					}	
				}
			})
		/**************************************************
		 *温度转换
		 **************************************************/
		  var Arr_temp = ["°C","°F"];
		  var len3 = Arr_temp.length;
		  for(var k = 0;k < len3;k++){
		 	$("<li/>").appendTo(".templist ul");
				$(".templist ul li").eq(k).html(Arr_temp[k]);
				$("<li><div/><span/></li>").appendTo("#temp_target");
				$("#temp_target li > span").eq(k).html(Arr_temp[k]);
		 }
		 $("#current_temp ul > li").click(function(){
				$("#current_temp > span").html($(this).text());
				$(".sourData:last").trigger("input");
			})
		 var tarDate3 = [];
		 function convC(x){
		 	tarDate3 = [x,x*1.8+32];
		 }
		 function convF(x){
		 	tarDate3 = [(x-32)/1.8,x];
		 }
		 $(".sourData:last").bind("input",function(){
		 	var $sourData = $(this).val();
				if($sourData == ""){
					$("#press_target li > div").html("");
				}
				else{
					$sourData = parseFloat($sourData);
					var $sourUnit = $("#current_temp > span").text();
					var index3 =jQuery.inArray($sourUnit,Arr_temp);
					if(index3 === 0){convC($sourData)};
					if(index3 === 1){convF($sourData)};
					tarDate3 = $.map(tarDate3,function(i){
						if(i > 10e8){
							return i.toExponential(2);
						}
						else{
							return i.toFixed(2);
						}
					})
					for(var l = 0;l < len3;l++){
						$("#temp_target li > div").eq(l).html(tarDate3[l]);
					}
				}		
		 })		


 //获取假数据
		 /* var data = [];
		 $.ajax({
		 	url: "../data/data.js",
		 	type: "get",
		 	success: function(res) {
		 		data = JSON.parse(res);
		 	}
		 });

		 $(".viewMore").click(function() {
		 	var length = $(".projectList .projectContent").length;
		 	$(".projectWrapper ul").css("display","block");
		 	if(length >= 10) {
		 	$('.viewMore').children(".pcontent").html('NO MORE')
		 		return;
		 	}
		 	var str = "";
		 	for(var i = 0; i < data.length; i++) {
				str += '<div class="projectContent">' +
							'<a href=""><img src="'+ data[i].img +'" alt="projectsImage"></a>' +
							'<section>' +
								'<a href="">' +
									'<h4>'+ data[i].title +'</h4>' +
									'<p>Application area : <span>'+ data[i].content +'</span></p>' +
									'<p>Project site : <span>Peru</span></p>' +
								'</a>' +
							'</section>' +
						'</div>';
		 	}
		 	$(".projectList").append(str);
		 }); */


})

