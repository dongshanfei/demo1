;(function(window) {

  var svgSprite = '<svg>' +
    '' +
    '<symbol id="icon-jiantou" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M591.552 1019.072 54.72 512.96 591.488 4.864 624.512 39.744 124.608 512.896 624.448 984.192Z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-jiantou-copy" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M432.448 4.928l536.832 506.112-536.768 508.096-33.024-34.879 499.904-473.151-499.84-471.296z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-jiantou-copy1" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M702.882 958.388l64.032-63.397-380.993-383.606 384.196-380.377-63.49-63.925-448.221 443.779z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-jiantou-copy2" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M343.215 64.571l-68.838 68.839 379.321 379.322-379.321 379.324 68.838 68.839 438.079-438.080v-20.162z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-jiantou-copy-copy" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M512 926.476c229.361 0 414.476-186.018 414.476-414.476s-186.018-414.476-414.476-414.476-414.476 186.018-414.476 414.476 185.115 414.476 414.476 414.476zM365.714 489.425l205.883-206.787c6.321-6.321 14.448-9.030 22.575-9.030s16.254 2.709 22.575 9.030c12.642 12.642 12.642 32.508 0 45.15l-184.212 184.212 183.309 181.503c12.642 12.642 12.642 32.508 0 44.246-12.642 12.642-32.508 12.642-44.246 0l-205.884-204.078c-6.321-6.321-9.030-13.545-9.030-22.575 0-7.224 2.709-15.351 9.030-21.672z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-jiantou-copy-copy-copy" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M512 97.524c-229.361 0-414.476 186.018-414.476 414.476s186.018 414.476 414.476 414.476 414.476-186.018 414.476-414.476-185.115-414.476-414.476-414.476zM658.286 534.575l-205.883 206.787c-6.321 6.321-14.448 9.030-22.575 9.030s-16.254-2.709-22.575-9.030c-12.642-12.642-12.642-32.508 0-45.15l184.212-184.212-183.309-181.503c-12.642-12.642-12.642-32.508 0-44.246 12.642-12.642 32.508-12.642 44.246 0l205.884 204.078c6.321 6.321 9.030 13.545 9.030 22.575 0 7.224-2.709 15.351-9.030 21.672z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-icon-copy" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M474.197 576.049c21.544 21.034 56.478 21.034 78.026 0l393.466-383.229c21.546-21.036 21.546-55.142 0-76.179s-56.48-21.037-78.026 0l-354.454 345.23-354.454-345.23c-21.549-21.037-56.482-21.037-78.028 0-21.547 21.036-21.547 55.142 0 76.179l393.467 383.228zM867.663 448.949l-354.454 345.23-354.454-345.23c-21.549-21.037-56.482-21.037-78.028 0-21.547 21.036-21.547 55.142 0 76.179l393.468 383.228c21.544 21.034 56.478 21.034 78.026 0l393.466-383.229c21.546-21.036 21.546-55.142 0-76.179-21.547-21.036-56.482-21.037-78.026 0z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-icon-double-arrow-up" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M549.803 447.951c-21.544-21.034-56.478-21.034-78.026 0l-393.466 383.229c-21.546 21.036-21.546 55.142 0 76.179s56.48 21.037 78.026 0l354.454-345.23 354.454 345.23c21.549 21.037 56.482 21.037 78.028 0 21.547-21.036 21.547-55.142 0-76.179l-393.467-383.228zM156.337 575.051l354.454-345.23 354.454 345.23c21.549 21.037 56.482 21.037 78.028 0 21.547-21.036 21.547-55.142 0-76.179l-393.468-383.228c-21.544-21.034-56.478-21.034-78.026 0l-393.466 383.229c-21.546 21.036-21.546 55.142 0 76.179 21.547 21.036 56.482 21.037 78.026 0z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-u-arrow3-left" viewBox="0 0 1000 1000">' +
    '' +
    '<path d="M417.312 167.312l-312.5 312.5c-24.406 24.406-24.406 63.969 0 88.376l312.5 312.5c24.406 24.406 63.969 24.406 88.376 0 24.406-24.406 24.406-63.969 0-88.376l-205.813-205.813h599.125c34.531 0 62.5-27.969 62.5-62.5s-27.969-62.5-62.5-62.5h-599.125l205.813-205.813c12.188-12.188 18.313-28.188 18.313-44.188s-6.095-32-18.313-44.188c-24.406-24.406-63.969-24.406-88.376 0z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-u-arrow3-right" viewBox="0 0 1000 1000">' +
    '' +
    '<path d="M606.688 856.688l312.5-312.5c24.406-24.406 24.406-63.969 0-88.376l-312.5-312.5c-24.406-24.406-63.969-24.406-88.376 0-24.406 24.406-24.406 63.969 0 88.376l205.813 205.813h-599.125c-34.531 0-62.5 27.969-62.5 62.5s27.969 62.5 62.5 62.5h599.125l-205.813 205.813c-12.188 12.188-18.313 28.188-18.313 44.188s6.095 32 18.313 44.188c24.406 24.406 63.969 24.406 88.376 0z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-jiantou-copy-copy-copy1" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M96.196 671.807l415.804-415.632 415.803 415.632-63.616 63.445-352.209-352.017-352.102 352.017z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-jiantou-down" viewBox="0 0 1102 1024">' +
    '' +
    '<path d="M921.196-255.996v0 0 0 0 0 0 0z"  ></path>' +
    '' +
    '<path d="M1009.812 330.442l-60.049-60.049-394.316 394.317-396.548-396.548-60.715 60.715 456.595 456.595z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '</svg>'
  var script = function() {
    var scripts = document.getElementsByTagName('script')
    return scripts[scripts.length - 1]
  }()
  var shouldInjectCss = script.getAttribute("data-injectcss")

  /**
   * document ready
   */
  var ready = function(fn) {
    if (document.addEventListener) {
      if (~["complete", "loaded", "interactive"].indexOf(document.readyState)) {
        setTimeout(fn, 0)
      } else {
        var loadFn = function() {
          document.removeEventListener("DOMContentLoaded", loadFn, false)
          fn()
        }
        document.addEventListener("DOMContentLoaded", loadFn, false)
      }
    } else if (document.attachEvent) {
      IEContentLoaded(window, fn)
    }

    function IEContentLoaded(w, fn) {
      var d = w.document,
        done = false,
        // only fire once
        init = function() {
          if (!done) {
            done = true
            fn()
          }
        }
        // polling for no errors
      var polling = function() {
        try {
          // throws errors until after ondocumentready
          d.documentElement.doScroll('left')
        } catch (e) {
          setTimeout(polling, 50)
          return
        }
        // no errors, fire

        init()
      };

      polling()
        // trying to always fire before onload
      d.onreadystatechange = function() {
        if (d.readyState == 'complete') {
          d.onreadystatechange = null
          init()
        }
      }
    }
  }

  /**
   * Insert el before target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var before = function(el, target) {
    target.parentNode.insertBefore(el, target)
  }

  /**
   * Prepend el to target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var prepend = function(el, target) {
    if (target.firstChild) {
      before(el, target.firstChild)
    } else {
      target.appendChild(el)
    }
  }

  function appendSvg() {
    var div, svg

    div = document.createElement('div')
    div.innerHTML = svgSprite
    svgSprite = null
    svg = div.getElementsByTagName('svg')[0]
    if (svg) {
      svg.setAttribute('aria-hidden', 'true')
      svg.style.position = 'absolute'
      svg.style.width = 0
      svg.style.height = 0
      svg.style.overflow = 'hidden'
      prepend(svg, document.body)
    }
  }

  if (shouldInjectCss && !window.__iconfont__svg__cssinject__) {
    window.__iconfont__svg__cssinject__ = true
    try {
      document.write("<style>.svgfont {display: inline-block;width: 1em;height: 1em;fill: currentColor;vertical-align: -0.1em;font-size:16px;}</style>");
    } catch (e) {
      console && console.log(e)
    }
  }

  ready(appendSvg)


})(window)