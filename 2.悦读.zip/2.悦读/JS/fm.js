window.onload=function(){
    // 头部标题栏点击设置
    var menu=document.getElementById('menu');
    var btnA=menu.getElementsByTagName('a');
    for(var i=0;i<btnA.length;i++){
        btnA[i].index=i;
        btnA[i].onclick=function(){
            for(var j=0;j<btnA.length;j++){
                 btnA[j].style.color="#707070";
            }
            btnA[this].style.color="red";
        }
        
    }

   

    // 中间内容文字的隐藏
	var none=document.getElementById('none');
	var down=document.getElementById('down');
	down.onclick=function(){
		if(down.innerHTML == "展开全文 ∨"){
			none.style.display="block";
			down.innerHTML="收起 ∧"
		}else{
			none.style.display="none";
			down.innerHTML="展开全文 ∨"
		}
	}
	
	

    //   中间内容右上边的切换
    // var teb=document.getElementById('teb');
/*    var teb1=document.getElementById('teb1');
    var teb2=document.getElementById('teb2');
    var teb3=document.getElementById('teb3');
    var qr=document.getElementById('QR');*/
    // var img=teb.getElementsByTagName('img')
  
    teb1.onmouseover=function(){
        teb1.src="images/31.png";
        teb1.style.width="53px";
        teb1.style.height="53px";
    }
    teb1.onmouseout=function(){
        teb1.src="images/7.png";
    }
 
    teb2.onmouseover=function(){
        teb2.src="images/32.png";
        teb2.style.width="53px";
        teb2.style.height="53px";
    }
    teb2.onmouseout=function(){
        teb2.src="images/8.png";
    }

    teb3.onmouseover=function(){
        teb3.src="images/33.png";
        teb3.style.width="53px";
        teb3.style.height="53px";
        qr.style.display="block";
    }
    teb3.onmouseout=function(){
        teb3.src="images/10.png";
        qr.style.display="none";
    }


    //   底部图标的切换
    var img3=document.getElementById('img3');

    img3.onmouseover=function(){
        img3.src="images/37.png";
    }
    img3.onmouseout=function(){
        img3.src="images/17.png";
    }

// 登录页面
/*    var denglu=document.getElementById('denglu');
    var zhuce=document.getElementById('zhuce');
    var logon=document.getElementById('logon');
    var register=document.getElementById('register');
    var close=document.getElementById('close');
    var close2=document.getElementById('close2');
    var mask=document.getElementById('mask');
    var h5=mask.getElementsByTagName('h5');
    denglu.onclick=function(){
        mask.style.display="block";
        logon.style.display="block";
        register.style.display="none";
    }
    h5[0].onclick=function(){
        mask.style.display="none";
        logon.style.display="none";
    }

    zhuce.onclick=function(){
        mask.style.display="block";
        register.style.display="block";
    }
    h5[1].onclick=function(){
        mask.style.display="none";
        register.style.display="none";
    }*/

//封装登录页面 有滑动效果
    function Mask(handle,ele){
        this.handle = document.getElementById(handle);
        this.box = document.getElementById(ele);
        this.masking = document.getElementById('back');
        this.close = this.box.getElementsByTagName('h5')[0];
        this.bWidth = window.innerWidth||document.documentElement.clientWidth||document.body.clientWidth;
        this.boxWidth = this.box.offsetWidth;
        this.target = (this.bWidth-this.boxWidth)/2;
        this.speed = 10;
    }
//方法写在原型对象中
    Mask.prototype.move = function(ele,target,speed,callback){
        clearInterval(ele.timer);
        var speed = ele.offsetLeft<target?speed:-speed;
        ele.timer = setInterval(function(){
            var val = ele.offsetLeft - target;
            if(Math.abs(val)<=Math.abs(speed)){
                clearInterval(ele.timer);
                ele.style.left =target+"px";
                if(callback){
                    callback();
                }
             }else{
               ele.style.left =  ele.offsetLeft + speed +"px"; 
            }
        },10)
    };

    //定义start函数
    Mask.prototype.start = function(){
        this.masking.style.display = "block";
        this.box.style.visibility = "visible";
        this.move(this.box,this.target,this.speed);
    }; 

    //定义stop函数
    Mask.prototype.stop = function(){
        var _this = this;
        this.move(this.box,this.bWidth,this.speed,function(){
            _this.masking.style.display = "none";
            _this.box.style.visibility = "hidden";
            _this.box.style.left = "0";
        });
    }; 

    //定义初始化函数
    Mask.prototype.init = function(){
        var _this = this;
        this.handle.onclick = function () {//给对应的元素绑定相关事件
            _this.start();//this指向对象
        }
        this.close.onclick = function(){
            _this.stop();
        }
    }; 

    var reg = new Mask('denglu',"logon");
    reg.init();
    var login = new Mask('zhuce','register');
    login.init();







}