window.onload=function(){
   //   底部图标的切换
    var img1=document.getElementById('img1');
    var img2=document.getElementById('img2');
    var img3=document.getElementById('img3');
    var none1=document.getElementById('none1');
    var none2=document.getElementById('none2');
    var none3=document.getElementById('none3');

    img1.onmouseover=function(){
		none1.style.display="block";
    }
    img1.onmouseout=function(){
       none1.style.display="none";
    }
 
    img2.onmouseover=function(){
		none2.style.display="block";
    }
    img2.onmouseout=function(){
        none2.style.display="none";
    }

    img3.onmouseover=function(){
        img3.src="images/37.png";
    }
    img3.onmouseout=function(){
        img3.src="images/17.png";
    }



//封装登录页面
    function Mask(handle,ele){
        this.handle = document.getElementById(handle);
        this.box = document.getElementById(ele);
        this.masking = document.getElementById('back');
        this.close = this.box.getElementsByTagName('h5')[0];
        this.bWidth = window.innerWidth||document.documentElement.clientWidth||document.body.clientWidth;
        this.boxWidth = this.box.offsetWidth;
        this.target = (this.bWidth-this.boxWidth)/2;
        this.speed = 10;
    }
//方法写在原型对象中
    Mask.prototype.move = function(ele,target,speed,callback){
        clearInterval(ele.timer);
        var speed = ele.offsetLeft<target?speed:-speed;
        ele.timer = setInterval(function(){
            var val = ele.offsetLeft - target;
            if(Math.abs(val)<=Math.abs(speed)){
                clearInterval(ele.timer);
                ele.style.left =target+"px";
                if(callback){
                    callback();
                }
             }else{
               ele.style.left =  ele.offsetLeft + speed +"px"; 
            }
        },10)
    };

    //定义start函数
    Mask.prototype.start = function(){
        this.masking.style.display = "block";
        this.box.style.visibility = "visible";
        this.move(this.box,this.target,this.speed);
    }; 

    //定义stop函数
    Mask.prototype.stop = function(){
        var _this = this;
        this.move(this.box,this.bWidth,this.speed,function(){
            _this.masking.style.display = "none";
            _this.box.style.visibility = "hidden";
            _this.box.style.left = "0";
        });
    }; 

    //定义初始化函数
    Mask.prototype.init = function(){
        var _this = this;
        this.handle.onclick = function () {//给对应的元素绑定相关事件
            _this.start();//this指向对象
        }
        this.close.onclick = function(){
            _this.stop();
        }
    }; 

    var reg = new Mask('denglu',"logon");
    reg.init();
    var login = new Mask('zhuce','register');
    login.init();










}