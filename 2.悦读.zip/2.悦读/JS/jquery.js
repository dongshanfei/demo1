window.onload=function(){
    // 中间内容文字的隐藏
    var none=document.getElementById('none');
    var down=document.getElementById('down');
    down.onclick=function(){
        if(down.innerHTML == "展开全文 ∨"){
            none.style.display="block";
            down.innerHTML="收起 ∧"
        }else{
            none.style.display="none";
            down.innerHTML="展开全文 ∨"
        }
    }


    //   中间内容右上边的切换 JS方法
    // var teb=document.getElementById('teb');
 /*   var teb1=document.getElementById('teb1');
    var teb2=document.getElementById('teb2');
    var teb3=document.getElementById('teb3');
    var qr=document.getElementById('QR');
    // var img=teb.getElementsByTagName('img')
        teb1.onmouseover=function(){
        teb1.src="images/31.png";
        teb1.style.width="53px";
        teb1.style.height="53px";
    }
    teb1.onmouseout=function(){
        teb1.src="images/7.png";
    }
 
    teb2.onmouseover=function(){
        teb2.src="images/32.png";
        teb2.style.width="53px";
        teb2.style.height="53px";
    }
    teb2.onmouseout=function(){
        teb2.src="images/8.png";
    }

    teb3.onmouseover=function(){
        teb3.src="images/33.png";
        teb3.style.width="53px";
        teb3.style.height="53px";
        qr.style.display="block";
    }
    teb3.onmouseout=function(){
        teb3.src="images/10.png";
        qr.style.display="none";
    }*/
    //   中间内容右上边的切换 jquery方法
  $(function(){
    $('#teb1').hover(function(){
        $(this).attr('src','images/31.png');
        $(this).attr('width','53px');
        $(this).attr('height','53px');
    },function(){
        $(this).attr('src','images/7.png');
    })

    $('#teb2').hover(function(){
        $(this).attr('src','images/32.png');
        $(this).attr('width','53px');
        $(this).attr('height','53px');
    },function(){
        $(this).attr('src','images/8.png');
    })

    $('#teb3').hover(function(){
        $(this).attr('src','images/33.png');
        $(this).attr('width','53px');
        $(this).attr('height','53px');
        $('#QR').show();
    },function(){
        $(this).attr('src','images/10.png');
        $('#QR').hide();
    })
  })


    //   底部图标的切换
    var img1=document.getElementById('img1');
    var img2=document.getElementById('img2');
    var img3=document.getElementById('img3');
    var none1=document.getElementById('none1');
    var none2=document.getElementById('none2');
    var none3=document.getElementById('none3');

    img1.onmouseover=function(){
        none1.style.display="block";
    }
    img1.onmouseout=function(){
       none1.style.display="none";
    }
 
    img2.onmouseover=function(){
        none2.style.display="block";
    }
    img2.onmouseout=function(){
        none2.style.display="none";
    }

    img3.onmouseover=function(){
        img3.src="images/37.png";
    }
    img3.onmouseout=function(){
        img3.src="images/17.png";
    }

    //登录和注册
    $(function(){
        $('#denglu').on('click',function(){
            $('#back').show();
            $('#logon').show().animate({
                left:'50%',
                marginLeft:'-190px'
            });
        })

        $('#zhuce').on('click',function(){
            $('#back').show();
            $('#register').show().animate({
                left:'50%',
                marginLeft:'-190px'
            });
            $('#logon').hide();
        })

        $('.del').on('click',function(){//关闭按钮
            $(this).parents('.hide').animate({
                left:'1920px',
                marginLeft:0
            },function(){
                $(this).css('left',0)
                $('#back').hide(),
                $(this).hide()
            });
        })
    })

//设置登录信息和注册信息
    $(function(){
        var reg=/^\w{6,12}$/;
        var lgUser=12465555;
        console.log(lgUser)
        console.log(reg.test(lgUser));
    })
    


    //图片轮播
    $(function(){
        var count=0;
        var length=$('.col-item').length-1;
        var liWidth=$('.col-item').innerWidth();
        $('.col-items').width(liWidth*(length+1)+'px');
        $('#next').on('click',function(){
            if(count<length){
                count++;
                if(count>0){
                    $('#pre').removeClass('none')
                }
                $('.col-items').animate({
                    left:(-liWidth)*count+'px'
                },function(){
                    if(count==length){
                        $('#next').addClass('none')
                    }
                })
            }
            
        })

        $('#pre').on('click',function(){
            if(count>0){
                count--;
                if(count<length){
                    $('#next').removeClass('none')
                }
                $('.col-items').animate({
                    left:(-liWidth)*count+'px'
                },function(){
                    if(count==0){
                        $('#pre').addClass('none')
                    }
                })
            }
        })

    })
        
//评论区

$(function(){
    $('.content-lf-btn').on('click',function(){
        var a=$('.content-lf-comment').children().html();
        var $text="<p><span class='span1'><a href=''>"+$('.content-lf-say-text').val()+"</a></span><span class='span'>"+"x"+"</span></p>";
        if($('.content-lf-say-text').val()==""){
            alert('请输入内容')
        }else{
            $('.content-lf-comment').children().html(++a);
            if(a==1){
                $('.content-lf-fff').html($text);
                // alert($p)
            }else{
                $('.content-lf-fff').prepend($text);
            }
        }
        $('.content-lf-say-text').val('')
        $('.span').on('click',function(){
            if(a<1){
                $('.content-lf-fff').html('<p>暂无评论</p>');
            }else{
                $(this).parent().remove();
                // console.log(this)
            }
            $('.content-lf-comment').children().html(--a);
        })
    })
})



}
