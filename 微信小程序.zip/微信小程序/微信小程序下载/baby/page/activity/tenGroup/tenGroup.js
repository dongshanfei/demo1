Page({
    data: {
        bannerUrl: "http://m.ipinbb.com/ipbb/static/images/promotionsBg.png",
        lists: [{
            imgUrl: "http://img.alicdn.com/imgextra/i4/2258468951/TB28OeOmFXXXXXcXXXXXXXXXXXX_!!2258468951.jpg",
            title: "6人团-婴儿奶瓶夹奶嘴夹",
            groupSize: "6人团",
            groupPrice: "9.50",            
        },{
            imgUrl: "http://img.alicdn.com/imgextra/i1/2085953362/TB29astmVXXXXbzXXXXXXXXXXXX_!!2085953362.jpg",
            title: "6人团-强力管道疏通剂",
            groupSize: "6人团",
            groupPrice: "9.70",            
        },{
            imgUrl: "http://img.alicdn.com/imgextra/i3/TB1JffyLXXXXXX.aXXXXXXXXXXX_!!0-item_pic.jpg",
            title: "6人团-宝宝洗脸盆",
            groupSize: "6人团",
            groupPrice: "6.80",            
        },{
            imgUrl: "http://service.ipinbb.com:8080/ImageService/GetImage?imageName=475--475__group1__$$M00$$00$$30$$CgoSrFfFS-iAGr2uAACA6oZHpcw322.jpg",
            title: "6人团-加厚圆形晾衣架",
            groupSize: "6人团",
            groupPrice: "8.10",            
        }]
    }
})