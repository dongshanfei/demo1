Page({
    data: {
        bannerUrl: "http://m.ipinbb.com/ipbb/static/images/limited-banner.png",
        lists: [{
            dateTime: "11月03日",
            goodsSize: "3",
            listItems: [{
                goodsId: "3243789729",
                platformId: "1",
                title: "3人团-自发热保暖防寒磁疗护膝",
                imgUrl: "http://img.alicdn.com/imgextra/i2/159474411/TB2ZXROag9J.eBjSsppXXXAAVXa_!!159474411.jpg",
                endTime: "17",
                groupPrice: "46.20",
                oddPrice: "98.00",
                discount: "7.9",
                groupSize: "3人团",
                goodsFrom: "淘宝",
                fromPrice: "58.00"
            },
            {
                goodsId: "3243789729",
                platformId: "1",
                title: "4人团-自发热保暖防寒磁疗护膝",
                imgUrl: "http://img.alicdn.com/imgextra/i2/159474411/TB2ZXROag9J.eBjSsppXXXAAVXa_!!159474411.jpg",
                endTime: "17",
                groupPrice: "46.20",
                oddPrice: "98.00",
                discount: "8.9",
                groupSize: "4人团",
                goodsFrom: "京东",
                fromPrice: "158.00"
            },
            {
                goodsId: "3243789729",
                platformId: "1",
                title: "3人团-自发热保暖防寒磁疗护膝",
                imgUrl: "http://img.alicdn.com/imgextra/i2/159474411/TB2ZXROag9J.eBjSsppXXXAAVXa_!!159474411.jpg",
                endTime: "17",
                groupPrice: "46.20",
                oddPrice: "98.00",
                discount: "7.9",
                groupSize: "3人团",
                goodsFrom: "淘宝",
                fromPrice: "58.00"
            }]
        },{
            dateTime: "11月02日",
            goodsSize: "1",
            listItems: [{
                goodsId: "3243789729",
                platformId: "1",
                title: "3人团-自发热保暖防寒磁疗护膝",
                imgUrl: "http://img.alicdn.com/imgextra/i2/159474411/TB2ZXROag9J.eBjSsppXXXAAVXa_!!159474411.jpg",
                endTime: "17",
                groupPrice: "46.20",
                oddPrice: "98.00",
                discount: "7.9",
                groupSize: "3人团",
                goodsFrom: "淘宝",
                fromPrice: "58.00"
            }]
        }]
    }
})