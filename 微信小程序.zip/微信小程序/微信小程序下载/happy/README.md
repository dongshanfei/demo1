# 微信小程序－逗乐

### 说明：

实现了纯文字，纯图片，图文混合编排等功能。

### 数据接口:

使用本地数据

### 目录结构：

- images — 存放项目图片文件
- pages — 存放项目页面渲染相关文件
- utils — 存放日期格式化文件

### 开发环境：

微信web开发者工具 v0.11.112200

### 项目截图：

https://www.getweapp.com/project?projectId=583459f9bb2538f8186c709b

### 感谢：
本项目原始版本由mkxiansheng提供：https://github.com/mkxiansheng/doule
