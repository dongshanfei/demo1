//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    name: 'GetWeApp',
    pic_url: 'http://ogth2odq7.qnssl.com/G-%20%281%29.png',
    github: 'https://github.com/getweapp/weapp-doule'
  },
  onLoad: function () {

  }
})
