//index.js
//获取应用实例
var app = getApp()
Page({
  data: {
    dec: "收藏页，正在准备，稍安勿躁！",
    req: []
  },
  onLoad () {

  }
})

