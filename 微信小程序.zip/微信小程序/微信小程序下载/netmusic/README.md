# netmusic-app
仿网易云音乐APP的微信小程序


node后台接口代码已经发到github 有需求的可以自己部署，欢迎star，请勿使用我的服务器地址。
后台项目启动后 utils文件中新建bsurl.js文件  输入module.exports="启动地址"

 [动图演示地址：](http://7vik7b.com1.z0.glb.clouddn.com/20170308_112339.gif)

 
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4271.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4279.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4274.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4272.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4276.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4277.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4275.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4273.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4278.PNG"/>

##目前实现功能

1. 用户
2. 歌单
3. FM
4. 播放
5. 评论
6. MV
7. 专辑
8. 歌手
9. 登录
10. 歌曲红心,FM trash，收藏单曲至歌单
11. 收听记录
12. 歌单歌曲推荐
13. 迷你播放条
14. 电台，节目
15. 搜索

##TODO

* 增加评论，评论点赞等 
* 歌词翻译
* 收藏(歌单，歌手，专辑，电台
* 音质切换
* 用户动态，粉丝
* 新歌 新专 分类电台

目前代码结构混乱 是时候来一波大重构了。