# WXAppTrain

微信小程序：火车票查询

接口：百度APIStore去哪网火车票查询
http://apistore.baidu.com/apiworks/servicedetail/697.html

功能：站-站火车票信息查询
1、指定出发地、目的地、时间，获取所有车次并显示基本信息
2、点击某一车次，显示所有座位信息

Github
https://github.com/VincentWYJ/WXAppTrain.git

博客：
http://www.cnblogs.com/tgyf/p/5960979.html
