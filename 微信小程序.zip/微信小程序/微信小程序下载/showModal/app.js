import city from '/utils/city';
App({
  onLaunch: function () {
  },
  cityObj: city
})
