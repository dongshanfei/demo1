Page({
        calling: function () {
          wx.makePhoneCall({
            phoneNumber: '0371-86686767', 
            success: function () {
              console.log("拨打电话成功！")
            },
            fail: function () {
              console.log("拨打电话失败！")
            }
          })
        },
        calling_1: function () {
          wx.makePhoneCall({
            phoneNumber: '400-839-1110',
            success: function () {
              console.log("拨打电话成功！")
            },
            fail: function () {
              console.log("拨打电话失败！")
            }
          })
        },
        
  data: {
    latitude: 34.8080150000,
    longitude: 113.5456110000,
    markers: [{
      latitude: 34.8080150000,
      longitude: 113.5456110000,
      name: '郑州锅炉股份有限公司'
    }],
    covers: [{
      latitude: 34.8080150000,
      longitude: 113.5456110000,
      // iconPath: 'image/location.png'
    }, {
        latitude: 34.8080150000,
        longitude: 113.5456110000,
      // iconPath: 'image/location.png'
    }]
  }
})
