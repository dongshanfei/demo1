/*
	options 
		odd 默认为red 为class名
		even 默认为blue class名
		hover 默认为white class名

*/

;(function($){
	$.fn.table = function(options){
		var defaults = {
			odd:"red",
			even:"blue",
			hover:"white"
		}
		var settings = $.extend({},defaults,options);
		/*
			表格的奇数行是一个颜色 red
				  偶数行是另外一个颜色  blue
			
			$(":eq()")
			$(':odd')   //奇数的jquery对象
			$(':even')  //偶数的jquery对象
		*/
		this.find("tr:odd").addClass(settings.odd);
		this.find("tr:even").addClass(settings.even);
		// this.find('tr').hover(function(){
		// 	$(this).addClass("white");
		// },function(){
		// 	$(this).removeClass("white");
		// })
		this.find('tr').hover(function(){
			$(this).toggleClass(settings.hover);
		})

		return this;
	}


}(jQuery))