;(function(window) {

  var svgSprite = '<svg>' +
    '' +
    '<symbol id="icon-iconfontyoujiantou" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M511.698636 62.998823C264.159844 62.998823 63.489498 263.667122 63.489498 511.205914s200.670346 448.208115 448.209138 448.208115 448.208115-200.670346 448.208115-448.208115S759.237429 62.998823 511.698636 62.998823zM724.462414 530.540262c-0.678452 1.480724-1.472538 2.616594-1.939165 3.267417-0.217964 0.38988-0.433882 0.801249-0.652869 1.215688-1.257643 2.382257-2.926656 5.544273-5.808286 8.559956l-0.189312 0.192382c-0.179079 0.182149-0.350994 0.345877-0.512676 0.497327-0.575098 0.823761-1.208525 1.585101-1.889023 2.266623L451.314361 799.212374c-9.376555 9.018398-21.684882 13.984503-34.663474 13.984503-13.719466 0-26.497491-5.434779-35.977399-15.299451-19.085684-19.818371-18.500353-51.494815 1.308809-70.606081l225.702462-217.537502L381.148301 295.451012c-19.995403-18.932188-20.87647-50.610678-1.966795-70.617337 9.41544-9.928117 22.650883-15.618723 36.31509-15.618723 12.811794 0 24.995277 4.846378 34.305317 13.646811l264.368086 250.048963C729.758024 487.632009 733.895251 510.792499 724.462414 530.540262z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-left" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M510.903527 62.421678c247.683079 0 448.462918 200.814632 448.462918 448.547853 0 247.730151-200.779839 448.546829-448.462918 448.546829-247.682056 0-448.460872-200.816678-448.460872-448.546829C62.442656 263.235286 263.221472 62.421678 510.903527 62.421678L510.903527 62.421678zM298.00058 530.331507c0.683569 1.494027 1.455141 2.629897 1.956561 3.266393 0.208754 0.394996 0.422625 0.819668 0.636496 1.197268 1.240247 2.38021 2.939959 5.533017 5.819542 8.593725l0.166799 0.165776 0.500397 0.50142c0.558725 0.810459 1.210571 1.591241 1.876744 2.2656l262.321474 252.867148c9.395998 9.05012 21.700231 14.013155 34.68701 14.013155 13.71435 0 26.521027-5.433756 35.977399-15.308661 19.10922-19.825534 18.502399-51.534723-1.303692-70.677713L414.795633 509.513366l226.647997-214.461443c20.004613-18.946514 20.881586-50.640354 1.985214-70.677713-9.426697-9.930163-22.657023-15.642259-36.340673-15.642259-12.836353 0-24.990161 4.862751-34.30941 13.653975L308.243875 472.632387c-15.592117 14.71719-19.742646 37.912471-10.272971 57.662281L298.00058 530.331507zM298.00058 530.331507"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-shang" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M904 692c0 8.189-3.124 16.379-9.372 22.628-12.497 12.496-32.759 12.496-45.256 0L512 377.255 174.628 714.628c-12.497 12.496-32.758 12.496-45.255 0-12.497-12.498-12.497-32.758 0-45.256l360-360c12.497-12.496 32.758-12.496 45.255 0l360 360C900.876 675.621 904 683.811 904 692z" fill="" ></path>' +
    '' +
    '</symbol>' +
    '' +
    '<symbol id="icon-xia" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M904 332c0-8.189-3.124-16.379-9.372-22.628-12.497-12.496-32.759-12.496-45.256 0L512 646.745 174.628 309.372c-12.497-12.496-32.758-12.496-45.255 0-12.497 12.498-12.497 32.758 0 45.256l360 360c12.497 12.496 32.758 12.496 45.255 0l360-360C900.876 348.379 904 340.189 904 332z" fill="" ></path>' +
    '' +
    '</symbol>' +
    '' +
    '</svg>'
  var script = function() {
    var scripts = document.getElementsByTagName('script')
    return scripts[scripts.length - 1]
  }()
  var shouldInjectCss = script.getAttribute("data-injectcss")

  /**
   * document ready
   */
  var ready = function(fn) {
    if (document.addEventListener) {
      if (~["complete", "loaded", "interactive"].indexOf(document.readyState)) {
        setTimeout(fn, 0)
      } else {
        var loadFn = function() {
          document.removeEventListener("DOMContentLoaded", loadFn, false)
          fn()
        }
        document.addEventListener("DOMContentLoaded", loadFn, false)
      }
    } else if (document.attachEvent) {
      IEContentLoaded(window, fn)
    }

    function IEContentLoaded(w, fn) {
      var d = w.document,
        done = false,
        // only fire once
        init = function() {
          if (!done) {
            done = true
            fn()
          }
        }
        // polling for no errors
      var polling = function() {
        try {
          // throws errors until after ondocumentready
          d.documentElement.doScroll('left')
        } catch (e) {
          setTimeout(polling, 50)
          return
        }
        // no errors, fire

        init()
      };

      polling()
        // trying to always fire before onload
      d.onreadystatechange = function() {
        if (d.readyState == 'complete') {
          d.onreadystatechange = null
          init()
        }
      }
    }
  }

  /**
   * Insert el before target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var before = function(el, target) {
    target.parentNode.insertBefore(el, target)
  }

  /**
   * Prepend el to target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var prepend = function(el, target) {
    if (target.firstChild) {
      before(el, target.firstChild)
    } else {
      target.appendChild(el)
    }
  }

  function appendSvg() {
    var div, svg

    div = document.createElement('div')
    div.innerHTML = svgSprite
    svgSprite = null
    svg = div.getElementsByTagName('svg')[0]
    if (svg) {
      svg.setAttribute('aria-hidden', 'true')
      svg.style.position = 'absolute'
      svg.style.width = 0
      svg.style.height = 0
      svg.style.overflow = 'hidden'
      prepend(svg, document.body)
    }
  }

  if (shouldInjectCss && !window.__iconfont__svg__cssinject__) {
    window.__iconfont__svg__cssinject__ = true
    try {
      document.write("<style>.svgfont {display: inline-block;width: 1em;height: 1em;fill: currentColor;vertical-align: -0.1em;font-size:16px;}</style>");
    } catch (e) {
      console && console.log(e)
    }
  }

  ready(appendSvg)


})(window)