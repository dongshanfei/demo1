$(function(){
   var i = 0;
   var imgWidth = $(".head-carousel ul li").width();
   var clone = $(".head-carousel ul li").first().clone();
   $(".head-carousel ul").append(clone);
   //复制第一张图片并且添加到最后达到无缝连接的效果
   
   var length = $(".head-carousel ul li").length;//得到所有li的个数
   
   //开始循环添加按钮
   for(var j = 0 ; j<length- 1 ; j++){
     $("#controler").append("<div></div>");   
   }
  
   $("#controler div").eq(0).addClass("onclick");
   
   //按钮移出移入事件
   $("#controler div").hover(function(){
      i = $(this).index();  
      clearInterval(timer);
      $(".head-carousel ul").stop().animate({left:-i * imgWidth});
      $(this).addClass("onclick").siblings().removeClass("onclick");
     },function(){
       timer = setInterval(function(){
       Toleft();    
     },2000)    
   })      
   
   //定时器
   var timer = setInterval(function(){
     Toleft();    
       
   },2000)   
   

   function Toleft(){
     i++;
     if(i==length){
        $(".head-carousel ul").css({left:0});
        i = 1;     
     }
     $(".head-carousel ul").stop().animate({left:-i*imgWidth},2000);
     if(i == length -1){
        $("#controler div").eq(0).addClass("onclick").siblings().removeClass("onclick"); 
     }else{
       $("#controler div").eq(i).addClass("onclick").siblings().removeClass("onclick");           
    }
   }
   
   function Toright(){
      i--;
      if(i==-1){
         $(".head-carousel ul").css({left:-(size - 1)*imgWidth});
         i=length-2;    
      }   
      $(".head-carousel ul").animate({left:-i*imgWidth},2000);  
      $("#controler div").eq(i).addClass("onclick").siblings().removeClass("onclick"); 
   }

     //收集到堆糖的箭头
      $(".blue-tool").hover(function(){
         $(".images-arrow").css("display","block")
      },function(){
        var  t = setTimeout(function(){
            $(".images-arrow").css("display","none")
        },3000)
      }
      )
      //最左边那个列表的显示
      $("#nofind").on("click",function(){
          $(".browsers").css("display","block")
      })
      //这个一直显示不成
      $("#hover").attr({
        "background":"#d7eafb",
        "color":"#e47878"
      })
});

  // 下载客户端页面的js jquery
    $(function(){
        $("#copy-rqs .copy").hover(function(){
                $(this).addClass("border")
            },function(){
                 $(this).removeClass("border")
        })
       
        $(".header-right .h-eq").css("display","none")
        $(".header-right .h-phone").hover(function(){
           $(".header-right .h-eq").css("display","block")
        },function(){
           $(".header-right .h-eq").css("display","none")
        })
    })  

    //登录页面的验证的js
    window.onlaod = function(){
    var user = document.getElementById('user');
    var pass = document.getElementById('pass');
   
      function blur(ele,reg){
        var sp = ele.nextSibling;
        sp.innerHTML = "";
        if(!reg.test(ele.value)){
            sp.innerHTML = "*密码由6-18位字符组成, 区分大小写";
        }
      }

      user.onblur = function(){
        var sp = this.nextSibling;
        if(this.value == ""){
           sp.innerHTML = "*用户名不能为空";
          }
      }

      pass.onblur = function(){
         blur(this,/^\d{6,}$/);
      }
 }
