$(function(){
    // 图片tab切换
    $('#nav li').on('click',function(){
        $('#nav li').removeClass('font');
        $(this).addClass('font');
        $('.hide').hide();
        $('.hide').eq($(this).index()).show();
    })
})