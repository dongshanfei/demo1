window.onload = function(){
    var inputEmail = document.getElementById('input-email');
    var inputCode = document.getElementById('input-code');
    var yesimg = document.getElementById('images-success');
    var emailText = document.getElementById('email-text');
    var sub = document.getElementById('submit');
   

    function focus(ele){
        ele.style.background =  "#faffbd";
        ele.style.border = "1px #efefef  solid";
    }
    function blur(ele,reg){
        ele.style.background =  "#fff";
        ele.style.border = "1px #efefef  solid";
        yesimg.style.display = "none";
        emailText.style.display = "none";
        var flag = true;
        if(reg){
            if(reg.test(ele.value)){
                yesimg.style.display = "block";
            }else{
                emailText.style.display = "block";
                flag = false;
            }
        }
    }


    inputEmail.onfocus = function(){
      focus(this);
    }
    inputCode.onfocus = function(){
       focus(this);
    }
    inputEmail.onblur = function(){
      blur(this,/^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/);
    }
    inputCode.onblur = function(){
       blur(this);
    }
}