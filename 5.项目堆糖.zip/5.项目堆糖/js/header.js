$(function(){
    $(".header-right .h-eq").css("display","none")
    $(".header-right .h-phone").hover(function(){
        $(".header-right .h-eq").css("display","block")
        },function(){
        $(".header-right .h-eq").css("display","none")
     })
})