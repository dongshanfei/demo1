$(function(){
	//整页面轮播(插件)
 	var swiper = new Swiper('.swiper-container', {
        pagination: '.swiper-pagination',//分页选择器
        direction: 'vertical',//垂直滚动
        slidesPerView: 1,//现实的数量
        paginationClickable: true,//分页选择器师傅能否被选择
        spaceBetween: 0,//页面之间是否存在间隔
        mousewheelControl: true,//鼠标滚动操作 mousewheel(jq鼠标滚动事件)
        preventLinksPropagation : true,//鼠标点击了页面
        onSlideChangeEnd: function(swiper){//切换进入时，执行操作
	     console.log(swiper.activeIndex);
	     if(swiper.activeIndex == 1){
	      	$('.pc').animate({
		      	opacity:'1',
		      	top:'10%'
		     },1000)
	     }else{
      		$('.pc').css({
      			top:'15%',
      			opacity:0
      		})
	     }
	     if(swiper.activeIndex == 2){
	      	$('.phone').animate({
		      	opacity:'1',
		      	top:'10%'
		     },1000)
	     }else{
      		$('.phone').css({
      			top:'15%',
      			opacity:0
      		})
	     }
	      
	    }/*,
	    onSlideChangeStart: function(swiper){//切换结束时，执行操作
	   
	      
	    }*/
	});

	//返回顶部
	$('.toTop').on('click',function(){
		/*$('.swiper-wrapper').css({
			'transform': 'translate3d(0px, 0px, 0px)',
			'transition-duration': '0ms'
		})
		index = 0
		$('.swiper-slide').removeClass('swiper-slide-active').removeClass('swiper-slide-prev').removeClass('swiper-slide-next')
		$('.swiper-slide').eq(0).addClass('swiper-slide-active')
		$('.swiper-slide').eq(1).addClass('swiper-slide-next')
		$('.swiper-pagination-bullet').removeClass('swiper-pagination-bullet-active')
		$('.swiper-pagination-bullet').eq(0).addClass('swiper-pagination-bullet-active')*/
		swiper.slideTo(0, 1000, false);//切换到第一个slide，速度为1秒
	})
})