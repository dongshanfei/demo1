// 右上脚点击图片出现分享图标
$(function(){
    $('.task-top-collect-b').hover(function(){
        $('#share').show()
    },function(){
        $('#share').hide()
    })
})