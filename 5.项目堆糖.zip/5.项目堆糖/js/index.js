// 轮播js
$(function(){
	var w = $('.lunboimg li').width();
	var clon = $('.lunboimg li').first().clone();
	$('.lunboimg').append(clon);
	$('.lunboimg').css('width',$('.lunboimg li').length*w);
	var count = 0;
	$("#pre").click(preBtn)
	function preBtn(){//上一页
		$("#pre").off()
		count--;
		if(count>0){
			move(count,function(){
				$("#pre").click(preBtn)
			});
			changedots(count);
		}else{
			$('.lunboimg').css('left',($('.lunboimg li').length-1)*-w);
			move($('.lunboimg li').length-2,function(){
				$("#pre").click(preBtn)
			});
			count = $('.lunboimg li').length-2;
			changedots(count);
		}
	}
	$("#next").click(nextBtn)
	function nextBtn(){//下一页
		clearTimeout(t)
		$("#next").off()
		count++;
		if(count<$('.lunboimg li').length-1){	
			move(count,function(){
				t = setTimeout(function(){
					$("#next").click()
				},2000)
				$("#next").click(nextBtn)
			});
			changedots(count);
		}else{
			move(count,function(){
				$('.lunboimg').css('left',0);
				count = 0;
				t = setTimeout(function(){
					$("#next").click()
				},2000)
				$("#next").click(nextBtn)
			});
			changedots(0);
		}
	}
	function move(count,callback){
		$('.lunboimg').animate({
			left:-w*count
		},1000,callback)
	}
	function changedots(count){//小圆点
		$(".dots li").removeClass().eq(count).addClass('active');
	}
	$(".dots li").click(function(){
		changedots($(this).index());
		count = $(this).index();
		move(count);
	})
	var t = setTimeout(function(){
		$("#next").click()
	},2000)
	$('#lunbo').hover(function(){
		clearTimeout(t)
		$("#pre").show();
		$("#next").show();
	},function(){
		$("#pre").hide();
		$("#next").hide();
		t = setTimeout(function(){
			$("#next").click()
		},1000)
	})

	// 登录显示
	$('#loEnter').on('click',function(){
		$('#back').fadeIn();
		$('#login').fadeIn();
		$('#loginClose').on('click',function(){
			$('#back').fadeOut();
			$('#login').fadeOut();
		})
	})
	// 返回顶部
	$(document).on('scroll',function(){
		// console.log($(document).scrollTop())
		if($(document).scrollTop()>500){
			$('#toTop').fadeIn()
		}else{
			$('#toTop').fadeOut()
		}
	})
	$('#toTop').on('click',function(){
		$('body,html').animate({
			scrollTop:0
		})
	})
	if($(document).scrollTop()>500){
		$('#toTop').fadeIn()
	}
})