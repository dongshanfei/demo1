window.onload = function(){
    var user = document.getElementById('user');
    var emali= document.getElementById('emali');
    var relevant = document.getElementById('relevant');
            function focus(ele){
                ele.style.border = "1px #efefef  solid ";
                ele.style.background = "#faffbd";
            }
            function blur(ele){
                ele.style.border = "1px #efefef  solid ";
                ele.style.background = "#fff";
            }
            function userblur(ele){
                var sp = ele.nextSibling;
                sp.innerHTML = "";
                if(ele.value == ""){
                    sp.innerHTML = "请填写您的称呼！";
                    sp.className = "warn";
                }else{
                    sp.className = "";
                }
            }
            user.onfocus = function(){
                focus(this);
            }
            emali.onfocus = function(){
                focus(this);
            }
            relevant.onfocus = function(){
                focus(this);
            }
            user.onblur= function(){
                blur(this);
                userblur(this);
            }
            emali.onblur = function(){
                blur(this);
            }
            relevant.onblur = function(){
                blur(this);
            }
       
}
     $(function(){
        function btn_toggle(a,b,c,d){
            $("."+c).css("display","none");
            if(!d){
               d = "li";      
            }
            $("."+b).on("click",function(){
                var ind = $(this).index()+1;
                $("."+c).css("display","none");
                var m = "."+a+" "+d;
                $(m).eq(ind).css("display","block");
            }); 
        };
        btn_toggle("ul","problem","ananswer")
     })
   
   
        