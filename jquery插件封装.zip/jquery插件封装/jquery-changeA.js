;(function($){
	//写出插件的结构
	$.fn.changeA = function(options){
		// this调用该方法的jquery对象
		var defaults = {
			color:"#333",
			textDecoration:"underline",
			background:'red'
		}
		var settings = $.extend({},defaults,options);//会自动将两个对象合并,如果有相同属性，后面覆盖前面
			/*

				{
					color:"red",
					textDecoration:"underline",
					background:'red'
				}

			*/
		this.css({
			color:settings.color,
			textDecoration:settings.textDecoration,
			background:settings.background
		})

		return this;//支持链式调用
	}

}(jQuery))

;(function($){
	$.fn.插件名 = function(options){
		var defaults = {

		}

		var setting = $.extend({},defaults,options);//得到的是三个对象合并后的结果

		/*进行操作*/


		//返回this
		return this;
	}

}(jQuery))