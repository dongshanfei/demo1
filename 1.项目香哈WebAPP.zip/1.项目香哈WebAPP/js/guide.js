var myswiper=new Swiper("#swiper-container1",{pagination:".swiper-pagination",paginationClickable:!0,onSlideChangeEnd: function(swiper){
      if(swiper.activeIndex == $('#swiper-container1 .swiper-slide').length-1){
      	window.open("index.html")
      } //切换结束时，告诉我现在是第几个slide
    }});