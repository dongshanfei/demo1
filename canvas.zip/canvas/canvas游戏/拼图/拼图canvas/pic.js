 //创建需要操作的游戏对象
 var ImgBoxGame = (function () {
     //canvas 的各个初始化设置
     var canvasHeight = 0, //存储canvas的高度
         canvasWidth = 0, //存储canvas的宽度
         newImg = document.createElement('img'),
         newImgWidth, //存储新建图片宽度
         newImgHeight, //存储新建图片高度
         pathDom, drawDom, //设置获取路径和绘制按钮的dom节点
         that, //保存的实例化对象
         canvasImgData = []; //保存绘制出来的图片信息 canvasImgData.last canvasImgData.white 


     //存储绘制过的图片的相关参数
     var drawImg = {
         drewImgHeight: 0, //存储绘制之后图片高度
         drewImgWidth: 0, //存储绘制之后的图片宽度    
         sliceNumber: [], //设置分割数目       
         sliceWidth: 0, //切割过后一小片的宽度
         sliceHeight: 0, //切割过后一小片的高度
         sliceOn: 4, //当前使用的切割数目
         sliceSpace: 3 //当前使用的切割分割大小    
     };

     //存储当前移动色块与白板的位移差及相关数据
     var displacement = {
         x: 0, //x轴上的位移差
         y: 0, //y轴上的位移差
         moveX: 0, //每次移动的X轴的距离
         moveY: 0, //每次移动的Y轴的距离
         fps: 24, //移动动画的帧数        
         isMoving: false //是否正在处于移动状态
     }

     //设定构造函数
     var IMGBoxGame = function (canvas, pathDomId, drawDomId) {
         that = this; //保存实例化的对象

         //判断是否传递了有效地参数
         if (canvas && pathDomId && drawDomId) {
             //外部调用参数
             this.canvas = document.getElementById(canvas).getContext('2d');
             this.isAnimate = true;


             //设定初始化的各个参数
             canvasHeight = document.getElementById(canvas).height;
             canvasWidth = document.getElementById(canvas).width;

             //初始化判断，是否已经选择了图片
             if (newImg.src) {
                 this.canvas.drawImage(newImg, 0, 0);
             } else {
                 this.canvas.fillText("还没有选择一张图片", 10, 10);
             }

             //添加对应的操作节点
             pathDom = document.getElementById(pathDomId);
             drawDom = document.getElementById(drawDomId);

             //设置操作节点的对应方法
             pathDom.onchange = function () {
                 //每次选择图片的时候都切换src地址
                 newImg.src = getImgPath(pathDomId);
                 that.imgSrc = newImg.src;
             }
             drawDom.onclick = function () {
                 //点击绘制的时候，重新初始化canvas图片                        
                 that.InitImg();
                 that.imgSrc = newImg.src;
             }

         } else {
             alert('需要传递完整地canvasid，获取图片Input的id和点击事件的id');
         }
     }

     //绘制小块图片函数,并且存储相关的图片信息

         function drawOnCanvas() {
             //存储canvas上图片切片大小
             drawImg.sliceWidth = drawImg.drewImgWidth / drawImg.sliceOn;
             drawImg.sliceHeight = drawImg.drewImgHeight / drawImg.sliceOn;

             for (var y = 0; y < drawImg.sliceOn; y++) {
                 canvasImgData[y] = [];
                 for (var x = 0; x < drawImg.sliceOn; x++) {
                     //在canvas对应区域绘制图片
                     that.canvas.drawImage(newImg, x * newImgWidth / drawImg.sliceOn, y * newImgHeight / drawImg.sliceOn, newImgWidth / drawImg.sliceOn, newImgHeight / drawImg.sliceOn, (getSlicePositionInCanvas(x, y).x), (getSlicePositionInCanvas(x, y).y), drawImg.sliceWidth, drawImg.sliceHeight);
                     //存储canvas图片相关信息                     
                     canvasImgData[y][x] = that.canvas.getImageData((getSlicePositionInCanvas(x, y).x), (getSlicePositionInCanvas(x, y).y), drawImg.sliceWidth, drawImg.sliceHeight);
                 }
             }
             //将坐标位置设定为最后一个图片块
             x--;
             y--;
             //最后一张图片信息保存下来
             canvasImgData.last = that.canvas.getImageData((getSlicePositionInCanvas(x, y).x), (getSlicePositionInCanvas(x, y).y), drawImg.sliceWidth, drawImg.sliceHeight);
             //清除最后一处的图片
             that.canvas.clearRect((getSlicePositionInCanvas(x, y).x), (getSlicePositionInCanvas(x, y).y), drawImg.sliceWidth, drawImg.sliceHeight);
             //获取空白图片的信息,并且存储对应的数组位置
             canvasImgData.white = {
                 x: x,
                 y: y
             }
             canvasImgData[y][x] = that.canvas.getImageData((getSlicePositionInCanvas(x, y).x), (getSlicePositionInCanvas(x, y).y), drawImg.sliceWidth, drawImg.sliceHeight);
             window.canvasImgData = canvasImgData;
             console.log(canvasImgData);
         }

         //通过传递对应的色块坐标确定其在canvas上的位置

         function getSlicePositionInCanvas(x, y) {
             var obj = {};
             obj.x = (x + 1) * drawImg.sliceSpace + x * (drawImg.sliceWidth);
             obj.y = (y + 1) * drawImg.sliceSpace + y * (drawImg.sliceHeight);
             return obj;
         }

         //绘制对应块的像素级图片

         function putImgDataInCanvas(x, y, moveX, moveY, times, clx, cly) {
             if (arguments.length == 2) {
                 that.canvas.putImageData(canvasImgData[y][x], getSlicePositionInCanvas(x, y).x, getSlicePositionInCanvas(x, y).y);
                 displacement.isMoving = false;
             } else if (arguments.length == 7) {
                 if (cly == y && clx == x) {
                     displacement.isMoving = false;
                 } else {

                     var clearPositionX = 0,
                         clearPositionY = 0,
                         clearWidth = 0,
                         cleaeHeight = 0; //设置清除左上角
                     if (cly == y) {
                         clearPositionY = getSlicePositionInCanvas(x, y).y;
                         clearPositionX = (x < clx) ? getSlicePositionInCanvas(x, y).x : getSlicePositionInCanvas(clx, cly).x;
                         clearWidth = drawImg.sliceWidth * 2 + drawImg.sliceSpace;
                         cleaeHeight = drawImg.sliceHeight;
                     } else if (clx == x) {
                         clearPositionX = getSlicePositionInCanvas(x, y).x;
                         clearPositionY = (y < cly) ? getSlicePositionInCanvas(x, y).y : getSlicePositionInCanvas(clx, cly).y;
                         cleaeHeight = drawImg.sliceHeight * 2 + drawImg.sliceSpace;
                         clearWidth = drawImg.sliceWidth;
                     }

                     var setTimer = function () {

                         setTimeout(function () {
                             times--;
                             that.canvas.clearRect(clearPositionX, clearPositionY, clearWidth, cleaeHeight);
                             that.canvas.putImageData(canvasImgData[y][x], getSlicePositionInCanvas(x, y).x - moveX * times, getSlicePositionInCanvas(x, y).y - moveY * times);
                             if (times > 0) {
                                 setTimer();
                             } else {
                                 displacement.isMoving = false;
                             }
                         }, 300 / displacement.fps);
                     }
                     setTimer();
                 }
             }

         }

         //清除对应块的像素级图片

         function clearImgDataInCanvas(x, y) {
             that.canvas.clearRect(getSlicePositionInCanvas(x, y).x, getSlicePositionInCanvas(x, y).y, drawImg.sliceWidth, drawImg.sliceHeight);
         }

         //重绘canvas切片图形
     reDrewCanvasInScile = function (whiteX, whiteY, keyCode) {
         var temp = canvasImgData[whiteY][whiteX];
         console.log("keyCode" + keyCode);
         var scileX = whiteX,
             scileY = whiteY;
         switch (keyCode) {
         case 39:
             //点击向左
             //获取白块将要被转化到的位置
             scileX = (scileX - 1 >= 0) ? (scileX - 1) : 0;
             break;
         case 40:
             //点击向上
             scileY = (scileY - 1 >= 0) ? (scileY - 1) : 0;
             break;
         case 37:
             //点击向右
             scileX = (scileX + 1 < drawImg.sliceOn) ? (scileX + 1) : drawImg.sliceOn - 1;
             break;
         case 38:
             //点击向下
             scileY = (scileY + 1 < drawImg.sliceOn) ? (scileY + 1) : drawImg.sliceOn - 1;
             break;
         default:
             alert('只能通过上下左右操作')

         }
         //交换像素图片和白版的属性位置
         canvasImgData[whiteY][whiteX] = canvasImgData[scileY][scileX];
         canvasImgData[scileY][scileX] = temp;
         //更新白板位置
         canvasImgData.white.x = scileX;
         canvasImgData.white.y = scileY;
         //获取和位移差相关的数据
         displacement.x = getSlicePositionInCanvas(whiteX, whiteY).x - getSlicePositionInCanvas(scileX, scileY).x;
         displacement.y = getSlicePositionInCanvas(whiteX, whiteY).y - getSlicePositionInCanvas(scileX, scileY).y;

         displacement.moveX = displacement.x / displacement.fps;
         displacement.moveY = displacement.y / displacement.fps;
         //重新绘制像素块,根据白板和操作色块之间的位移差制作动画效果                          

         if (that.isAnimate) {
             putImgDataInCanvas(whiteX, whiteY, displacement.moveX, displacement.moveY, displacement.fps, scileX, scileY);
         } else {
             putImgDataInCanvas(whiteX, whiteY);
             putImgDataInCanvas(scileX, scileY);
         }
     }

     //键盘事件控制图片变化
     changeCanvasByKey = function (e) {
         e = e || window.event;

         if (typeof e == "number") {
             var keycode = e;
         } else {
             var keycode = e.which ? e.which : e.keyCode;
         }
         if (displacement.isMoving == false) {
             displacement.isMoving = true;
             reDrewCanvasInScile(canvasImgData.white.x, canvasImgData.white.y, keycode);
         }
         if (e.perventDefault) {
             e.perventDefault();
         } else {
             return false;
         }
     }
     //开启键盘事件
     document.onkeydown = changeCanvasByKey;

     /***
      ****       以下开始编写对外可调用接口
      ***/


     //外部接口——用于初始化图片或者是完整显示图片答案
     IMGBoxGame.prototype.InitImg = function () {
         console.log(newImg);

         //清除画布
         this.canvas.clearRect(0, 0, canvasWidth, canvasHeight);

         newImgHeight = newImg.height; //获取图片高度
         newImgWidth = newImg.width; //获取图片宽度                

         //获取按比例切割，最小切割数(暂定上限为15,下限为3)
         /*for (var i = 3; i <= 16; i++) {
             if (newImgWidth % i == 0 && newImgHeight % i == 0) {
                 drawImg.sliceNumber.push(i);
             }
         }
         console.log(drawImg.sliceNumber);
         if (drawImg.sliceNumber.length == 0) {
             alert('图片比例恶心，求换张图');
         }*/
         //设置当前使用的图片数目
         //drawImg.sliceOn = drawImg.sliceNumber[1];

         //判断图片大小比例，如果图片过大，则按比例缩小
         if (newImgWidth <= canvasWidth - (drawImg.sliceSpace * (drawImg.sliceOn + 1)) && newImgHeight < canvasHeight - (drawImg.sliceSpace * (drawImg.sliceOn + 1))) {
             //当图片大小比较小的时候，直接绘图
             drawImg.drewImgHeight = newImgHeight;
             drawImg.drewImgWidth=newImgWidth;
             //在canvas上绘制图片
             drawOnCanvas();
         } else {
             if (newImgWidth >= newImgHeight) {
                 //宽度超过高度，按比例缩小绘制图片大小                        
                 var drewImgHeight = (canvasWidth - drawImg.sliceSpace * (drawImg.sliceOn + 1)) * newImgHeight / newImgWidth;

                 //存储绘制在canvas上的图片信息
                 drawImg.drewImgHeight = drewImgHeight;
                 drawImg.drewImgWidth = canvasWidth - drawImg.sliceSpace * (drawImg.sliceOn + 1);

                 //在canvas上绘制图片
                 drawOnCanvas();

                 // this.canvas.drawImage(newImg, 0, 0, drawImg.drewImgWidth, drawImg.drewImgHeight);
             } else {
                 //高度超出宽度,按比例缩小绘制图片大小
                 var drewImgWidth = (canvasHeight - drawImg.sliceSpace * (drawImg.sliceOn + 1)) * newImgWidth / newImgHeight;
                 //存储绘制在canvas上的图片信息
                 drawImg.drewImgWidth = drewImgWidth;
                 drawImg.drewImgHeight = canvasHeight - drawImg.sliceSpace * (drawImg.sliceOn + 1);
                 //在canvas上绘制图片
                 drawOnCanvas();
             }
         }


     }

     //外部接口——用于切换动画效果
     IMGBoxGame.prototype.cutoverAnimate = function () {
         if (this.isAnimate) {
             this.isAnimate = false;
         } else {
             this.isAnimate = true;
         }
     }

     //外部接口——把最后一块填充上去
     IMGBoxGame.prototype.putLastSclileOn = function () {
         this.canvas.putImageData(canvasImgData.last, getSlicePositionInCanvas(canvasImgData.white.x, canvasImgData.white.y).x, getSlicePositionInCanvas(canvasImgData.white.x, canvasImgData.white.y).y);
     }

     //外部接口——把最后一块拿下来
     IMGBoxGame.prototype.outLastSclile = function () {
         this.canvas.clearRect(getSlicePositionInCanvas(canvasImgData.white.x, canvasImgData.white.y).x, getSlicePositionInCanvas(canvasImgData.white.x, canvasImgData.white.y).y, drawImg.sliceWidth, drawImg.sliceHeight);
     }

     //外部接口——打乱图片顺序
     IMGBoxGame.prototype.upsetCanvas = function () {
         var max;         
         if(arguments.length==0){
            max=50*drawImg.sliceOn;
         }else{
            if(typeof arguments[0]=="number" ){
                max=50*arguments[0]
            }
         }
         var temp = this.isAnimate;
         this.isAnimate = false;
         for (var i = 0; i < max; i++) {
             var code = Math.floor(Math.random() * 4) + 37;
             console.log(code);
             document.onkeydown(code);
         }
         this.isAnimate = temp;
     }

     //外部接口——增加游戏难度（增加方块数目）
     IMGBoxGame.prototype.moreDifficult = function () {
         if (drawImg.sliceOn < 10) {
             drawImg.sliceOn++;
             this.InitImg();
             this.upsetCanvas(drawImg.sliceOn);
         } else if (drawImg.sliceOn < 15) {
             alert('你TM在逗我？你拼的出来么？→_→');
             drawImg.sliceOn++;
             this.InitImg();
             this.upsetCanvas(drawImg.sliceOn);
         } else {
             alert('玩够了没啊！！！！！混蛋，不能再分了啊')
         }
     }

     //外部接口，降低难度（减少方块数目）
     IMGBoxGame.prototype.moreEasy = function () {
         if (drawImg.sliceOn > 2) {
             drawImg.sliceOn--;
             this.InitImg();
             this.upsetCanvas(drawImg.sliceOn);
         } else if (drawImg.sliceOn > 1) {
             alert('你为什么放弃治疗？');
             drawImg.sliceOn--;
             this.InitImg();
             this.upsetCanvas(drawImg.sliceOn);
         } else {
             alert('抱歉，本游戏不提供给低智商幼儿玩。。。。。');
         }
     }


     //直接返回对象的构造函数                  
     return IMGBoxGame;
 }());