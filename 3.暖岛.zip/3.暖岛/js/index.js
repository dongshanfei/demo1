window.onload = function(){
    var box = document.getElementById('box'),
        ul = box.getElementsByTagName('ul')[0],
        lis = ul.getElementsByTagName('li'),
        pre = document.getElementById('pre'),
        next = document.getElementById('next'),
        dot = document.getElementById('dot');
    var liWidth = lis[0].offsetWidth;
    var count = 0;
    var step = 20;

    //创建两个li
    var firstLi = lis[lis.length-1].cloneNode(true);
    var lastLi = lis[0].cloneNode(true);
    ul.appendChild(lastLi);
    ul.insertBefore(firstLi, lis[0]);
    ul.style.left = -liWidth+"px";
    //初始化
    ul.style.width = liWidth*lis.length + "px";
    var fr = document.createElement('div');
    fr.className = "dot clearfix";
    for(var i = 0;i<lis.length-2;i++){
        var em = document.createElement('em');
        em.index = i;
        fr.appendChild(em);
    }
    dot.appendChild(fr);

    var dots = document.getElementsByTagName('em');
    dots[0].className = "active";



    function prePage(){
        count--;
        changeImg();
    }
    function nextPage(){
        count++;
        changeImg();
    }

    function changeImg(){
        clearTimeout(t);
        pre.disabled = true;
        next.disabled = true;
        if(count >= lis.length-2){
            move(ul,-(count+1)*liWidth,step,function(){
                count = 0;
                ul.style.left = -(count+1)*liWidth+"px"; 
                pre.disabled = false;
                next.disabled = false;
                t = setTimeout(function(){
                    next.click();
                }, 2000)
            })
            changeDot(0);
        }else if(count<0){
            move(ul,-(count+1)*liWidth,step,function(){
                count = lis.length - 3;
                ul.style.left = -(count+1)*liWidth+"px";
                pre.disabled = false;
                next.disabled = false;
                t = setTimeout(function(){
                    next.click();
                }, 2000)
            })
            changeDot(lis.length - 3);
        }else{
            move(ul,-(count+1)*liWidth,step,function(){
                pre.disabled = false;
                next.disabled = false;
                t = setTimeout(function(){
                    next.click();
                }, 2000)
            })
            changeDot(count);
        }
    }

    //动画函数
    function move(ele,target,speed,callback){
        clearInterval(ele.time);
        var speed = ele.offsetLeft<target?speed:-speed;
        ele.time = setInterval(function(){
            var val = ele.offsetLeft - target;
            ele.style.left = ele.offsetLeft + speed + "px";
            if(Math.abs(val)<=Math.abs(speed)){
                clearInterval(ele.time);
                ele.style.left = target + "px";
                if(callback){
                    callback();
                }
            }
        }, 10);
    }
    function changeDot(num){
        for(var i = 0;i<dots.length;i++){
            dots[i].className = "";
        }
        dots[num].className = "active";
    }

    function init(){
        pre.onclick = prePage;
        next.onclick = nextPage;
        ul.onmousedown = function(event){
            clearTimeout(t);
            var e = event || window.event;
            var x = e.clientX - ul.offsetLeft;
            var clientX = e.clientX;
            
            // e.preventDefault()||(e.returnValue = false);
            ul.onmousemove = function(event){
                var e = event || window.event;
                ul.style.left = e.clientX - x + "px";
            }
            document.onmouseup = function(event){
                var e = event || window.event;
                if(Math.abs(e.clientX-clientX)>liWidth/2){
                    e.clientX<clientX?count++:count--;
                    changeImg();
                }else{
                    changeImg();
                }
                ul.onmousemove = "";
                document.onmouseup = "";
            }
            return false;
        }

        for(var i = 0;i<dots.length;i++){
            dots[i].onclick = function(){
                changeDot(this.index);
                count = this.index;
                changeImg();
            }
        }
        // 
        t = setTimeout(function(){
            next.click();
        }, 2000)
    }
    init();
}
