$(function(){
    //放大镜
    $(".simg").mousemove(function(event){
        $(".yinying").show();
        $(".bigimg").show();
            var e = event || window.event;
            e.preventDefault();
            var left = e.clientX - $(".yinying").width()/2 - $(".simg").offset().left;
            var top = e.clientY - $(".yinying").height()/2 - $(".simg").offset().top;
            if (left < 0) {
                left = 0;
            }else if (left>$(".simg").width()-$(".yinying").width()) {
                left = $(".simg").width()-$(".yinying").width()
            }
            if (top < 0) {
                top = 0;
            }else if (top>$(".simg").height()-$(".yinying").height()) {
                top = $(".simg").height()-$(".yinying").height()
            }
            $(".yinying").css({
                left: left+"px",
                top : top +"px"
            })
            $("#img").css({
                left: -$(".yinying").offset().left / $(".simg").width()*$("#img").width()+900+"px",
                top : -$(".yinying").offset().top / $(".simg").height()*$("#img").height()+89+"px"
            })
    })
    //图片切换
        $(".listA").on("click",function(){
            $("#box img").get(0).src = "../images/s1.jpg";
            $("#img").get(0).src = "../images/big1.jpg";
            $(".ssimg li img").get(0).src= "../images/ss1.jpg";
        })
        $(".listB").on("click",function(){
            $("#box img").get(0).src= "../images/s2.jpg";
            $("#img").get(0).src= "../images/big2.jpg";
            $(".ssimg li img").get(0).src= "../images/ss2.jpg";
        })
    //数值加减
    var a = $("#pamount").val(),
    input = document.getElementById("pamount");
    $(".simg").mouseout(function(){
        $(".yinying").hide();
        $(".bigimg").hide();
    })
    $(".add").on("click",function(){
        a++;
        input.value = a;
    })
    $(".minus").on("click",function(){
        a--;
        if (a<1) {
            a = 1;
        };
        input.value = a;
    })
    //轮播动画
    var count = 0;
    $(".col-item").css("width",$("ul").length*$("ul").width()+"px")
    $(".next").on("click",function(){
        if (count<$(".col-item ul").length-3) {
            count++;
            if (count>0) {
                $('.pre').removeClass('none');
            }
            $(".col-item").animate({
                "left": -$(".col-item ul").innerWidth()*count+"px"
            },1000,function(){
                if (count == $(".col-item ul").length-3) {
                    $('.next').addClass('none');
                }
            });
            console.log(count)
        }
    })
    $(".pre").on("click",function(){
        if (count>0) {
            count--;
            if (count<$(".col-item ul").length-1) {
                $('.next').removeClass('none');
            }
            if (count==0) {
                $('.pre').addClass('none');
            }
            $(".col-item").animate({
                "left": -$(".col-item ul").innerWidth()*count+"px"
            },1000,function(){
                if (count==0) {
                $('.pre').addClass('none');
            }
            });
        }
    })
    //tab切换
    $(".tabqiehuan a").on("click",function(){
        $(".tabqiehuan a").removeClass("border");
        $(this).addClass("border");
    })
    $(".tabqiehuan a").eq(0).on("click",function(){
        $(".jieshao").show();
        $(".islanders").hide();
    })
    $(".tabqiehuan a").eq(1).on("click",function(){
        $(".jieshao").hide();
        $(".islanders").show();
    })
})