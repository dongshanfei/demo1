$(function(){
// 头部的广告条播放
   
    function scroll(hh){
         var $hl = $(".h-list"),
     ht = parseFloat($(".h-list").css("top"));
        if (!$hl.is(":animated")) {
                    $hl.animate({
                        top: ht-hh
                    }, 500,function(){
                        //console.log($hl.css("top"))
                        if($hl.css("top")=="-72px"){
                            $hl.css("top",0)
                        }
                    });
                }
    }
    //第一次忘记写计时器，因此只能执行一次
    setInterval(function(){
           scroll(36)
    },2000)
    
    //主导航的下拉菜单实现
    // $(".nav-item").hover(function(){
    //     $(this).find(".j-nav-dropdown").css("display","block")
    // },function(){
    //     $(this).find(".j-nav-dropdown").css("display","none")
    // })
   //尾部的点击变换背景图实现
   //console.log($(".friend-link .friend1").css("backgroundPositionY"))
    $(".friend-link .frienda").hover(function(){
       $(this).css("backgroundPositionY","-43px")
    },function(){
        $(this).css("backgroundPositionY","-5px")
    })
    $(".friend-link .friendb").hover(function(){
       $(this).css("backgroundPositionY","-210px")
    },function(){
        $(this).css("backgroundPositionY","-170px")
    })

// 当鼠标滑动至240px处，头部隐藏只出现一个导航条效果
    $(window).scroll(function(){
        //获取滚动条的滑动距离
        var scrH=$(this).scrollTop();
        console.log(scrH)
        //滚动条的滑动距离大于240px时，tab-nav固定，及m-funcTab-fixed类名生效，
        if(scrH>=140){
            $("#js-funcTab").addClass("m-funcTab-fixed");
            $(".header").hide();
            $("#js-funcTabWrap").css("height","60px");
            $(".tab-logo-activity").hide();    
        }else{
            $("#js-funcTab").removeClass("m-funcTab-fixed");
            $(".header").show();
            $(".tab-logo-activity").show();
        }
    })


});