$(function () {
	$(".select").on("mouseenter",function(){
		$(".select ul").show();
		$(".select")
	})
	$(".select").on("mouseleave",function(){
		$(".select ul").hide();
	})
	$(".menubar").on("click",function(){
		if ($(".menubar div").text() == "显示选单") {
			$(".menubar div").text("隐藏选单");
			$(".menubar").removeClass("asd")
		}else if ($(".menubar div").text() == "隐藏选单"){
			$(".menubar div").text("显示选单");
			$(".menubar").addClass("asd")
		}
		$(".list").toggle()
	})
	var x ;
	$("#dianjia a").on("click",function(){
		$("#dianjia div").removeClass("active1")
		$(this).children().addClass("active1")
		console.log($(this).index())
	})
	$("#dianjia a").on("mouseenter",function(){
		$(this).children().addClass("active")
	})
	$("#dianjia a").on("mouseleave",function(){
		$(this).children().removeClass("active")
	})
	$("#dianjib a").on("click",function(){
		$("#dianjib div").removeClass("active1")
		$(this).children().addClass("active1")
		console.log($(this).index())
	})
	$("#dianjib a").on("mouseenter",function(){
		$(this).children().addClass("active")
	})
	$("#dianjib a").on("mouseleave",function(){
		$(this).children().removeClass("active")
	})
	$(".color a").on("click",function(){
		$(".color a").removeClass("border");
		$(this).addClass("border");
	})
	$(".leaf .picon-1").eq(0).hide();
	$(".leaf .picon-1").eq(2).hide();
	$(".leaf .picon-1").eq(13).hide();

})