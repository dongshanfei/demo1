// 用户注册用的表单验证 bof
(function ($, huawei) {
    jQuery.validator.methods.customRegular = function (value, element, param) {
        var r = param.test(value)
        return r;
    };

    huawei.changePasswordForm =
    function () {
        $("#Registerform")
        .off("submit").on("submit", function (e) {
            if (!$(this).validate().form()) {
                return false;
            }
        })
        .validate({
            ignore: [],
            onfocusout: function (element, event) {
                if (true || !this.checkable(element) && (element.name in this.submitted || !this.optional(element))) {
                    this.element(element);
                }
            },
            messages: {
                Email: {
                    required: '<i class="icon_error"></i>' + getForMsgFromH("EmailRequired"),
                    email: '<i class="icon_error"></i>' + getFormEmailInfo(),
                    customRegular: '<i class="icon_error"></i>' + getFormEmailInfo(),
                    remote: getForMsgEmailExist()
                },
                Password: {
                    required: '<i class="icon_error"></i>' + getForMsgFromH("PasswordRequired"),
                    maxlength: '<i class="icon_error"></i>' + getForMsgFromH("passwordMax"),
                    minlength: '<i class="icon_error"></i>' + getForMsgFromH("passwordMin")
                    /*, customRegular: '<i class="icon_error"></i>' + getFormMsgPasswordreg()*/
                },
                Name: {
                    required: '<i class="icon_error"></i>' + getForMsgFromH("FirstNameRequired")
                },
                Name1: {
                    required: '<i class="icon_error"></i>' + getForMsgFromH("LastNameRequired")
                },
                VerificationCode: {
                    required: '<i class="icon_error"></i>' + getFormRequiredInfo()
                }
            },
            rules: {
                Email: {
                    required: true,
                    //email: true,
                    customRegular: /^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/,
                    //customRegular: /^([a-zA-Z0-9]+[_|\-|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\-|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/,
                    remote: { url: $("#AccountModifyOrRegServiceUrl").val() + "?type=5", jsonpCallback: "jsonpCallback", jsonp: "callback", async: false, dataType: "jsonp" }
                },
                Password: {
                    required: true,
                    /* customRegular: /(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[^a-zA-Z0-9]).+/ ,*/
                    maxlength: 16,
                    minlength: 8
                },
                Name: {
                    required: true
                },
                Name1: {
                    required: true
                },
                VerificationCode: {
                    required: true
                }
            },
            errorPlacement: function (label, element) {
                //console.log(arguments);
                element.parents(".infor-write").first().find(".field_message").empty().append(label);
            }
        });

        //$(document).off('click').on("click", ".js-personal-information-form-submit", function (e) {
        //    if (!$("#Registerform").validate().form())
        //        return false;

        //    SubmitRegister();

        //    //$(this).parents("form").first().submit();
        //    //return false;
        //});

    }
    ;
})(jQuery, huawei);