(function($){
	$.fn.autoTextarea = function(opts){
		var defaults ={
			minHeight:null,
			maxHeight:null,
			isIE8:false
		};
		options = $.extend({},defaults,opts);
		var minHeight = options.minHeight,
		    maxHeight = options.maxHeight,
		    isIe8 = options.isIE8;
		    if(isIe8){
		    	this.on('propertychange',function(){
		    		autoHeightIE(this);
		    	});
		    	return false;
		    }else{
		    	this.on('propertychange input focus',function(){
		    		autoHeight(this);
		    	});
		    }
		
		function autoHeightIE(ele){	
			if(ele.scrollHeight > minHeight){
				 if (maxHeight && ele.scrollHeight > maxHeight) {
                        ele.style.height = maxHeight+'px';
					    ele.style.overflowY = 'auto';
                } else {
                       ele.style.height = ele.scrollHeight+'px';
					   ele.style.overflowY = 'hidden';
                };
			}		
		}
		function autoHeight(ele){
			$(ele).height(minHeight+'px');
			if(ele.scrollHeight > minHeight){
				 if (maxHeight && ele.scrollHeight > maxHeight) {
                        ele.style.height = maxHeight+'px';
					    ele.style.overflowY = 'auto';
                } else {
                       ele.style.height = ele.scrollHeight+'px';
					   ele.style.overflowY = 'hidden';
                };
			}			
		}
	}
})(jQuery);