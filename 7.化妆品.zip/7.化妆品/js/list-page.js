var lic = document.getElementById("list-commodity");
var ul = lic.getElementsByTagName("ul");
var li =lic.getElementsByTagName("li");
var btn = document.getElementsByClassName("btn");
var img = document.getElementsByClassName("list-bsc");

// console.log(ul.length);
// console.log(li.length);
// console.log(li.length);
// console.log(btn.length);
// console.log(img.length);
// console.log(ig.length);
for(var i =0;i<li.length;i++){ 
     li[i].index=i;
     li[i].onmouseenter = function(){
        for(var j = 0;j<li.length;j++){
             btn[j].style.display = "none"; 
             img[j].style.display = "none"; 
        }
        btn[this.index].style.display = "block";
        img[this.index].style.display = "block"; 
    }
    
 li[i].onmouseleave = function(){
    for(var j = 0;j<li.length;j++){
         btn[j].style.display = "none";
         img[j].style.display = "none";
   }
  }
}


