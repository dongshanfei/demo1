;(function(){
    var add = document.getElementsByClassName("add-c")[0];
    var car = document.getElementById("addition-car");
    var con = document.getElementById("continuing");
    var btn1 = con.getElementsByTagName("input")[0];
    var padlock = document.getElementById("padlock");

    var collect = document.getElementById("collect");
    var sh = document.getElementsByClassName("heart-shaped")[0];
    var cop = document.getElementById("collect-padlock");
    var ba = document.getElementById("backtrack");
    var bt = ba.getElementsByTagName("input")[0];
    var bt2 = ba.getElementsByTagName("input")[1];
    console.log(sh);
      car.style.display="none"
      collect.style.display="none";
      function arr(num1,num2){
         num1.onclick = function(){
            if(num2.style.display =="none"){
                  num2.style.display = "block";
            }else{
                num2.style.display = "none";
            }
         }
      }
   arr(add,car);
   arr(padlock,car);
   arr(btn1,car);
   arr(sh,collect);
   arr(cop,collect);
   arr(bt,collect);
   arr(bt2,collect);
  
  var minus = document.getElementById("minus");
   
   var re = document.getElementById("redu");
   var pl =document.getElementById("plus");
   console.log(pl)
   var co = minus.getElementsByTagName("input")[0];
   var val = parseInt(co.value);

   var i = 0;
   car.style.display="none"
   collect.style.display="none";
    pl.onclick = function(){
        val += 1;
        co.value = val;
        
    
}
    re.onclick = function(){
         if(val>1){
             val--;
             co.value = val;
             
         }else{
            val="1"
            co.value = val;
         }
    }

 }()) 
