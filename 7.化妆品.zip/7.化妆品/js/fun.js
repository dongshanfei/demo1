//1.设置(添加)cookie(键,键值,时间);
//调用格式:setCookie('name','good',4);
    function setCookie(Name,Value,eDay){
            var date=new Date();
            date.setTime(date.getTime()+eDay*24*3600*1000);
            date = date.toGMTString();      //转化为字符串，不用也可以
            document.cookie=Name+'='+Value+';expires='+date;
        }

//此种方法可不用转化非整天时间,但输入时间格式稍显繁琐;
//调用格式:_setCookie('name','Jack','2016/12/18 12:00:00');
    function _setCookie(Name,Value,eTime){
        var date=new Date(eTime);
        document.cookie=Name+'='+Value+';expires='+date;
    }
//2.通过cookie名移除cookie(键)
    function removeCookie(Name){
            var date = new Date();
            date.setTime(date.getTime()-24*60*60*1000);
            document.cookie = Name+"=1;expires="+date;
        }
//3.通过cookie名获取cookie(键)值
    function getCookie(Name){
        var arr=document.cookie.split(';');
        for(var i=0;i<arr.length;i++)
        {
            if(arr[i].trim().indexOf(Name+'=')==0)
            {
               return arr[i].trim().slice((Name+'=').length);
            }
        }
        return '';
    }

//4.移动动画(注意给dom的父元素加定位,以免影响offsetLeft的获取.给dom加绝对定位)
        function move(dom,target,speed,callback){
            clearInterval(dom.t);
            var speed=dom.offsetLeft>target?-speed:speed;
            dom.t=setInterval(function(){
                dom.style.left=speed+dom.offsetLeft+'px';
                if(Math.abs(dom.offsetLeft-target)<=Math.abs(speed))
                {   
                    clearInterval(dom.t);
                    dom.style.left=target+'px';
                    if(callback)
                    {
                        callback();
                    }
                }
            },10);
        }
    //用margin
        function _move(dom,target,speed,callback){
            clearInterval(dom.t);
            var speed=dom.offsetLeft>target?-speed:speed;
            dom.t=setInterval(function(){
                dom.style.marginLeft=speed+dom.offsetLeft+'px';
                if(Math.abs(dom.offsetLeft-target)<=Math.abs(speed))
                {   
                    clearInterval(dom.t);
                    dom.style.marginLeft=target+'px';
                    if(callback)
                    {
                        callback();
                    }
                }
            },10);
        }


//5.淡出动画  
    function fadeOut(dom,speed,callback){
        clearInterval(dom.t);
        var alpha=100;
        dom.t=setInterval(function(){
            alpha-=speed;
            dom.style.opacity=alpha/100;
            dom.style.filter='alpha(opacity='+alpha+')';
            if(alpha<=0)            
            {
                clearInterval(dom.t);
                if(callback)
                {
                    callback();
                }
            }
        },10)
    }

//6.Ajax的封装;
//调用方法
    /*ajax({
            type:"get/post",
            url:"",
            data:{name:"张三",age:18},
            async:true,
            dataType:"text/json",
            beforeSend:function(){},
            complete:function(){},
            success:function(data){
                console.log("张三数据接收成功");
            },
            error:function(){}
        })*/
//封装函数
    function ajax(opt){
                opt.type = opt.type||"POST";
                opt.url = opt.url||"";
                opt.async = opt.async || true;
                opt.dataType = opt.dataType || "json";
                opt.data = opt.data||{};
                opt.success = opt.success||function(){};
                opt.beforeSend = opt.beforeSend||function(){};
                opt.complete = opt.complete||function(){};
                opt.error = opt.error||function(){};
                var xhr;
                var data = [];
                for(var i in opt.data){
                    data.push(i+"="+opt.data[i]);
                }
                data = data.join('&');
                //创建xhr对象
                if(window.XMLHttpRequest){
                    xhr = new XMLHttpRequest();
                }else{
                    xhr = new ActiveXObject('Microsoft.XMLHTTP');
                }
                opt.beforeSend();
                //post or get
                if(opt.type.toUpperCase() == "POST"){
                    xhr.open('POST',opt.url,opt.async);
                    xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
                    xhr.send(data);
                }else{
                    xhr.open("GET",opt.url+"?key="+Math.random()+"&"+data,opt.async);
                    xhr.send();
                }

                xhr.onreadystatechange = function(){
                    if(xhr.readyState == 4){
                        opt.complete();
                        if(xhr.status == 200){
                            if(opt.dataType.toUpperCase()=="JSON"){
                                var result = JSON.parse(xhr.responseText);
                                opt.success(result);
                            }else{
                                opt.success(xhr.responseText);
                            }
                        }else if(xhr.status == 404){
                            opt.error(xhr.statusText);
                        }
                    }
                }
            }




