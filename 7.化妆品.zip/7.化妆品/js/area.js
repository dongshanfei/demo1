
window.onload = function(){
    var province = document.getElementById('region_id');
    var city = document.getElementById('city');
    var county = document.getElementById('s_county');
  var html = "<option value=\"\">请选择</option>";
    for(var i = 0;i<provinceJson.length;i++){
      // p[i]指代数组中每一个对象
      html+="<option value='"+provinceJson[i].id+"'>"+provinceJson[i].province+"</option>"
    }
    // console.log(html);
    province.innerHTML = html;


    province.onchange = function(){
      var val = this.value;
      console.log(val);
      var html = "<option value=\"\">请选择</option>";
      for(var i = 0;i<cityJson.length;i++){
        if(cityJson[i].parent == val|| val == cityJson[i].id){
          html+="<option value='"+cityJson[i].id+"'>"+cityJson[i].city+"</option>"
        }
      }
      city.innerHTML = html;
      county.innerHTML = "<option value=\"\">请选择</option>"
    }


    city.onchange = function(){
      var val = this.value;
      var html = "<option value=''>请选择</option>"
      for(var i = 0;i<countyJson.length;i++){
        if(countyJson[i].parent == val){
          html+="<option value='"+countyJson[i].id+"'>"+countyJson[i].county+"</option>"
        }
      }
      county.innerHTML = html;
    }
}