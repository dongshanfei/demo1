$(function(){
	   var state=getCookie("state");
	   console.log(state);
	if(state=="yes"){
		$('#shopping-cart').addClass("block");
		$("#nologin").removeClass("block");
	}else{
		$('#shopping-cart').removeClass("block");
		$("#nologin").addClass("block");

		$(".btn-login").click(function(){
			sessionStorage.setItem("name","购物车")
			window.location.href="login.html";
		});
		$(".btn-shopping").click(function(){
			window.location.href="index.html";
		})
	};
	
        	// 全选
   	$('#shopping-cart .check').on('click', function () {
	            if ($(this).attr('class').indexOf('check-all') >= 0) { //如果是全选，则把所有的选择框选中
             		if(this.checked){    
    				$("#shopping-cart .check").prop("checked", true);   
			}else{    
    				$("#shopping-cart .check").prop("checked", false); 
			}    
	            };
	            isCheckAll();//只要有一个未勾选，则取消全选框的选中状态          
	          	allTotal();//选完更新总计
        	});    

   	//检测是否要 自动全选
	function isCheckAll(){
		var isCheckAll = true;
			num=0;
		$('.check-one').each(function(){
			if($(this).prop('checked') == false){ //判断所有的选项中有没有没选择的
				isCheckAll = false;//如果有，则将状态变成false
				$(this).parents('tr').removeClass('selected');
				num++;
			}else{
				$(this).parents('tr').addClass('selected');
			}
		});
		$('#shopping-cart .check-all').prop('checked',isCheckAll);
		return num;		
	};


	//为每行添加事件
        	$("table").on('click',".reduce",function(){		//点击减少
		var countInput = $(this).next(),
			value = parseInt(countInput.val());
		if (value> 1) {
                        		countInput.val(value-1);
                        		trTotal($(this),countInput.val());
                    	};
		allTotal();
	}).on('click','.add',function(){				//点击增加
		var countInput = $(this).prev(),
			value = parseInt(countInput.val());
		countInput.val(value+1);
		trTotal($(this),countInput.val());
		allTotal();
	}).on('click','.delete',function(){				// 删除单行商品
		var con = confirm('确定要删除该宝贝吗');
		if(con){
			$(this).parents('tr').remove();
		};
		allTotal();
	}); 
	
	// 删除选中的商品
	$('.delect-select').on('click',function(){	
		num=0;		
		isCheckAll();					
		if(num == $('.check-one').size()){
			confirm('请先选择要删除的商品');
		}else{
			var con = confirm('您确定要删除选中的商品吗');
			if(con){
				if($('#shopping-cart .check-all').is(':checked')){
					$(this).parents('#shopping-cart').remove();
					$('.cart-noitems').css('display','block');
				}else{
					$('.check-one:checked').parents('tr').remove();
					allTotal();					
				}
			}
		}
	});
	
	
	//计算单行价格
	function trTotal(ele,count){
		var price = ele.parents('tr').find('.current-price span').text();		
		var total = ele.parents('tr').find('.total-price span');
		total.html((price*count).toFixed(2))  ;
	};

	//计算总价
	function allTotal(){
		var priceTotal = $('table .priceTotal');
		var selectedTotal = $('table .selectedTotal');
		var selectedCount = 0;
		var total = 0;
		$('.check-one').each(function(){
			if($(this).prop('checked') == true){
				var price = $(this).parents('tr').find('.total-price span').text();
				var count = $(this).parents('tr').find('.qty-name').val();
				selectedCount += parseInt(count);
				total += parseFloat(price);
			}
		});		
		priceTotal.html(total.toFixed(2)) ;
		selectedTotal.html(selectedCount);
	};

	//点击结算	
	$('.btn-checkout').on('click',function(){		
		num=0;
		isCheckAll();						
		if(num == $('.check-one').size()){	
			layer.open({
		  		content: '请先选购商品再结账！',
		  		scrollbar: false,
		  		end:function(){
		  			console.log('关闭')
		  		}
			});    			
    			$('.layui-layer-title').html('提示');    			
    			$('.layui-layer-btn .layui-layer-btn0').css({      							
    				backgroundColor:"#ff4281",
    				borderColor:"#ff4281"
    			});    			
		}else{					
			window.location = "./order.html";
		};		
	});

	

}());