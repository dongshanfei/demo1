// 轮播
;(function(){
    var banner=getClass("banner")[0];
    console.log(banner);
    var box=getClass("lunbo")[0];
    var lis=box.getElementsByTagName("li");
    var pre=document.getElementById("pre");
    var next=document.getElementById("next");
    var count=0;
    var dots=getClass("dot")[0].children;
    init();
    function init(){
        pre.style.zIndex="2";
        next.style.zIndex="2";
        lis[0].className="show";
        lis[0].style.zIndex="1";
        dots[0].children[0].className="active";
        pre.onclick=function(){
            count--;
            changeImage();
        }
        next.onclick=function(){
            count++;
            changeImage();
        }

        for(var i=0;i<dots.length;i++)
        {
            dots[i].onclick=function(num){
                return function(){
                    count=num;
                    changeColor();
                    if(lis[count].className!="show"){
                        changeImage();    
                    }
                }
            }(i);
        }
    }

    function changeColor(){
        for(var i=0;i<dots.length;i++)
        {
            dots[i].children[0].className="";
        }
        dots[count].children[0].className="active";
    }


    function changeImage(){
        var show=getClass("show")[0];
        pre.disabled=true;
        next.disabled=true;
        if(count>lis.length-1){
            count=0
        }else if(count<0){
            count=lis.length-1;
        }
        fadeOut(show,2,function(){
            show.className="";
            show.style.zIndex="0";
            show.style.opacity=1;
            show.style.filter='alpha(opacity=100)';
            lis[count].style.zIndex="1";
            pre.disabled=false;
            next.disabled=false;
        });
        lis[count].className="show";
        changeColor();
        changebkdcolor()
    }

    function changebkdcolor(){
        var arr=["rgb(208, 7, 17)","rgb(17, 49, 90)","rgb(117, 182, 246)","rgb(249, 249, 249)","rgb(196, 233, 251)","#940111"];
        banner.style.background=arr[count];
    }
}())


// lift
;(function(){
    var lift=getClass("lift")[0];
    console.log(lift);
    document.onscroll=function(){
        var top=document.body.scrollTop||document.documentElement.scrollTop;
        // console.log(top);
        if(top>500){
            lift.style.display="block";
        }else{
            lift.style.display="none";
        }
    }
}())

// //jQuery
// //login
// ;(function(){
//   $(".suba a").on("click",function(e){
//         if($("#login").html()=="登录"){
//             e.preventDefault();
//             alert("请登录");
//             window.location="login.html";
//             // console.log(this.innerText);
//             sessionStorage.setItem("name",this.innerText);
//         };
//     });

    
// //load
//     var state=getCookie("state");
//     console.log(state);
//     if(state=="yes"){
//         $("#login").html('<span>你好&nbsp;</span><span>'+localStorage.email+'</span>');
//         $("#register").html("/&nbsp;退出").on("click",function(e){
//             e.preventDefault();
//             setCookie("state","no",1);
//             window.location="index.html";
//         });
//         $("#login").on("click",function(e){
//             e.preventDefault();
//         });
//     }else{
//         $("#login").html('登录');
//         $("#register").html("/&nbsp;注册");
        
//         $(".header-nav-right span:first-child a").on("click",function(){
//             sessionStorage.setItem("name",this.innerText)
//         });
//     }

// }(jQuery))



/*key*/

$(".input input").on("input focus",function(){
    var html="";
    var val=$(".input input").val().trim();
    $(".key").show();
    if(val){
        $.ajax({
            url:"http://search.jumei.com/ajax_get_assoc_word",
            dataType:"jsonp",
            type:"post",
            data:{
                search:val
            },
            jsonp: "callback",
            jsonpCallback:"searchCallback",
            success:function(data){
                console.log(data);
                for(var i=0;i<data.length;i++){
                    html+='<li><span class="fl">'+data[i].q+'</span><label class="fr">约'+data[i].at+'件</label></li>'
                }
                $(".key").html(html);
            }
        })
    }
});

$(".input input").on("blur",function(){
    $(".key").hide();
})




