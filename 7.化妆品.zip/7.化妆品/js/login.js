;(function(){
	$("#email").on("focus",function(){
		console.log("good")
		$("#error1").removeClass("block");
	});
	$("#psd").on("focus",function(){
		$("#error2").removeClass("block");
	});

	$("#loginbtn").on("click",function(e){
		e.preventDefault();
		var $email=$("#email").val();
		var $psd=$("#psd").val();
		var rege=/[\w!#$%&'*+/=?^_`{|}~-]+(?:\.[\w!#$%&'*+/=?^_`{|}~-]+)*@(?:[\w](?:[\w-]*[\w])?\.)+[\w](?:[\w-]*[\w])?/;
		var regd=/\w{6,12}/;
		if(!rege.test($email)){
			$("#error1").addClass("block");
		}else{
			$("#error1").removeClass("block")
		}

		if(!regd.test($psd)){
			$("#error2").addClass("block");
		}else{
			$("#error2").removeClass("block");
		}

		if(rege.test($email)&&regd.test($psd)){
			$.ajax({
				url:"../js/json/data.json",
				async:true,
				type:"post",
				dataType:"json",
				data:{
					email:$email,
					password:$psd
				},
				success:function(data){
					// console.log(data)
					var check=true;
					if(data.require=="success"){
						var result=data.account;
						// console.log(result[0])
						for(var i in result){
							console.log(result[i])
							if($email==result[i].email&&$psd==result[i].password){
								var txt=sessionStorage["name"];
								setCookie("state","yes",1);
								var e=$email.split("@",1)[0];
								localStorage.setItem("email",e);
								check=false;
								switch (txt) {
									case "登录":
									window.location="index.html";
									break;
									case "个人中心":
									window.location="my-account.html";
									break;
									case "我的订单":
									window.location="my-orders.html"
									break;
									case "购物车":
									window.location="shoppingcart.html"
									break;
								}
								return;
							}
						}
					};
					if(check){
						$("#error3").addClass("block");
					}
				}
			});
		}
		
	});

}(jQuery))
