//jQuery
//login
;(function($){
  $(".suba a").on("click",function(e){
        if($("#login").html()=="登录"){
            e.preventDefault();
            alert("请登录");
            window.location="login.html";
            // console.log(this.innerText);
            sessionStorage.setItem("name",this.innerText);
        };
    });

    
//load
    var state=getCookie("state");
    console.log(state);
    if(state=="yes"){
        $("#login").html('<span>你好&nbsp;</span><span>'+localStorage.email+'</span>');
        $("#register").html("/&nbsp;退出").on("click",function(e){
            e.preventDefault();
            setCookie("state","no",1);
            window.location="index.html";
        });
        $("#login").on("click",function(e){
            e.preventDefault();
        });
    }else{
        console.log($("#login"));
        $("#register").html("/&nbsp;注册").on("click",function(){
            sessionStorage.setItem("name",this.innerText)
        });
        $("#login").html('登录').on("click",function(){
            sessionStorage.setItem("name",this.innerText)
        });
    }

}(jQuery))