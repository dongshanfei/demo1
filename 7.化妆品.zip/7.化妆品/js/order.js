$(function(){

	// 调出新增地址窗口
	$("#btnNewAddress").on("click",function(){
		$(".masking").show();
	})

	// 添加地址栏
    $("#btnSaveAddress").on("click",function(){         
    	$(".masking").hide();       
		$li = $("<li class='address-item fl'><div class='address-name-tel clearfix'><span class='address-name fl'>"+$("#firstname").val()+"</span><span class='address-tel fr'>"+$("#telephone").val()+"</span></div><div class='address-full'><span class='address-full' title='"+$("#region_id option:selected").val()+$("#city option:selected").val()+$("#s_county option:selected").val()+$("#street").val()+"'>"+$("#region_id option:selected").text()+$("#city option:selected").text()+$("#s_county option:selected").text()+$("#street").text()+"</span></div><div class='address-ctrl clearfix'> <div class='fl'><a class='ctrl-type ctrl-default' href='javascript:;' style='display:none'>默认地址</a><a class='ctrl-type ctrl-setdefault' href='javascript:;' data-address-id=''>设为默认地址</a></div><div class='fr'><a class='ctrl-type ctrl-edit' href='javascript:;' data-address-id=''>修改</a> <a class='ctrl-type ctrl-delete' href='javascript:;' data-address-id=''>删除</a></div></div></li>");
		$li.appendTo($("#addressList"));
		console.log($(".address-item"))
		console.log($("#region_id option").val())
		console.log($("#region_id option:selected").text())
	})


	/*事件委托
			.on("事件类型","事件作用目标",function(){
	
			})*/


	// 选择地址
	$("#addressList").on("click",".address-item",function(){
		var _this = this;
		$(".address-item").each(function(){
			$(this).removeClass("selected");
		})
		$(_this).addClass("selected");
	})

	// 设置默认地址
	$("#addressList").on("click",".ctrl-setdefault",function(){
		var _this = this;
		$(".ctrl-default").each(function(){
			$(this).hide();
			$(".ctrl-setdefault").show();
		})
		$(_this).siblings(".ctrl-default").show();
		$(_this).hide();
	})
	// 修改地址
	$("#addressList").on("click",".ctrl-edit",function(){
		$(".masking").show();
	})

	// 删除地址
	$("#addressList").on("click",".ctrl-delete",function(){
		$(this).parent().parent().parent().remove();
	})

	// 地址栏展开
	$("#btnMoreAddress").on("click",function(){
		$(".address-scroll-contain").css("max-height","500px");
		$(this).hide();
		$("#btnMoreAddress-close").show();
	})

	//地址栏收起
	$("#btnMoreAddress-close").on("click",function(){
		$(".address-scroll-contain").css("max-height","170px");
		$("#btnMoreAddress").show();
		$(this).hide();
	})

	// 新增地址窗口关闭
	$("#addressClose").on("click",function(){
		$(".masking").hide();
	})


})