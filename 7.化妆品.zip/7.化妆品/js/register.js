;(function(){
	$("#email").on("focus",function(){
		$("#error1").removeClass("block");
	});
	$("#psd").on("focus",function(){
		$("#error2").removeClass("block");
	});
	$("#apsd").on("focus",function(){
		$("#aerror").removeClass("block");
	});

	$("#registerbtn").on("click",function(e){
		// alert("good");
		e.preventDefault();
		var $email=$("#email").val();
		var $psd=$("#psd").val();
		var $apsd=$("#apsd").val();
		var rege=/[\w!#$%&'*+/=?^_`{|}~-]+(?:\.[\w!#$%&'*+/=?^_`{|}~-]+)*@(?:[\w](?:[\w-]*[\w])?\.)+[\w](?:[\w-]*[\w])?/;
		var regd=/\w{6,12}/;
		if(!rege.test($email)){
			$("#error1").addClass("block");
		}else{
			$("#error1").removeClass("block")
		}

		if(!regd.test($psd)){
			$("#error2").addClass("block");
		}else{
			$("#error2").removeClass("block");
		}

		if($psd!=$apsd){
			$("#aerror").addClass("block");
		}else{
			$("#aerror").removeClass("block");
		}

		if(rege.test($email)&&regd.test($psd)&&$psd==$apsd){
			if(!$("#chkbox").get(0).checked){
				alert("您未同意注册条款");
			}else{
				alert("您已注册成功");
				window.location="index.html"
			}
		}





		
	});


}(jQuery))