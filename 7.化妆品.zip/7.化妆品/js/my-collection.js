$(function(){
	$(".favorite .collect ul").on("mouseenter","li",function(){
		$(".favorite .collect ul li .icons").hide();
		var icons = $(this).find(".icons");
		icons.show();
		//点击右上角删除图标
		$(".favorite .collect ul").on("click",".icons",function(){
			var test = $(this).parents("li");
			$(".col-mask").show();
			//点击确定按钮
			$(".favorite .del-model .btns").on("click",".sure",function(){
				test.remove();
				$(".col-mask").hide();
				layer.alert("删除成功！",{
					icon:1,
					time: 2000,
					anim: 4,
					area: ["400px","150px"],
					btn: false
				})
			})
		})
		//点击遮罩的取消按钮
		$(".favorite .del-model").on("click",".cancel",function(){
			$(".col-mask").hide();
		})
		//点击"X"号
		$(".favorite .del-model").on("click",".close",function(){
			$(".col-mask").hide();
		})
	})
})