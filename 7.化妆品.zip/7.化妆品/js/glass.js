(function(){
    var nmf = document.getElementById("nmf");//小盒子
    var shade = document.getElementById("shade");//阴影
    var glass = document.getElementById("glass");//放大镜
    var ig = glass.getElementsByTagName("img")[0];//被放大的图片
    // shade.style.display="none"
    // glass.style.display="none"
    nmf.onmouseenter = function(){
        shade.style.display = "block";
        glass.style.display = "block";
    }
    nmf.onmouseleave = function(){
        shade.style.display = "none";
        glass.style.display = "none";
    }
    nmf.onmousemove = function(event){
        var e = event || window.event;
        var left = e.clientX - nmf.offsetLeft - shade.offsetWidth/2;

        var left = e.clientX - nmf.offsetLeft -shade.offsetWidth/2;
        var top = e.clientY - nmf.offsetTop - shade.offsetHeight/2;
        
        if(left<0){
            left = 0;
        }else if(left > nmf.offsetWidth-shade.offsetWidth){
            left = nmf.offsetWidth -shade.offsetWidth;
        }
        if(top<0){
            top = 0;
        }else if(top>nmf.offsetHeight - shade.offsetHeight){
            top = nmf.offsetHeight - shade.offsetHeight;
        }
        shade.style.left = left + "px";

        shade.style.top = top + "px";
        ig.style.left = -left/nmf.offsetWidth*ig.offsetWidth + "px";
        ig.style.top = -top/nmf.offsetHeight*ig.offsetHeight + "px";
 
 }     

}())