/*;(function(){
    //document.getElementsByClassName兼容
    
    // 个人中心tab切换
    var title = document.getElementById("title"),
        titleList = title.children,
        content = document.getElementsByClassName("content-des")[0],
        contentList = content.children;
        for(var i = 0; i < titleList.length; i++){
            titleList[i].index = i;
            titleList[i].onclick = function(){
                for(var j = 0; j < titleList.length; j++){
                    titleList[j].className = "";
                    contentList[j].style.display = "none";
                }
                titleList[this.index].className = "active";
                contentList[this.index].style.display = "block";
            }
        }
    //收藏夹模块儿
    var favorite = document.getElementsByClassName("favorite")[0],
        collect = favorite.getElementsByTagName("ul")[0],
        collectList = collect.children,
        icons = favorite.getElementsByClassName("icons"),
        colMask = document.getElementsByClassName("col-mask")[0],//遮罩
        close = colMask.getElementsByClassName("close")[0],//关闭
        cancel = colMask.getElementsByClassName("cancel")[0],
        sure = colMask.getElementsByClassName("sure")[0];
        colMask.style.display = "none";
        for(var i = 0; i <collectList.length; i++){
            collectList[i].index = i;
            collectList[i].onmouseenter = function(){
               
                show(icons[this.index],colMask);
                show(close,colMask);//点击"X"的效果
                show(cancel,colMask);//点击"取消"按钮
                for(var j = 0; j < icons.length; j++){
                    icons[j].style.display = "none";
                }
               icons[this.index].style.display = "block";
            }
            collectList[i].onmouseleave = function(){
                for(var m = 0; m < icons.length; m++){
                    icons[m].style.display = "none";
                }
            }
        }
        //封装遮罩显示与隐藏函数
        function show(ele1,ele2){
            ele1.onclick = function(event){
                event.stopPropagation();
                if(ele2.style.display == "none"){
                    ele2.style.display = "block";
                }else{
                    ele2.style.display = "none";
                }
            }
        }
    //收货地址模块
    var add = document.getElementsByClassName("add-details")[0],
        addList = add.children,
        font = add.getElementsByTagName("ul"),
        delAdd = add.getElementsByClassName("del-add"),
        addMask = document.getElementsByClassName("add-mask")[0],//删除地址的遮罩
        addCancel = addMask.getElementsByClassName("cancel")[0],
        addSure = addMask.getElementsByClassName("sure")[0],
        addClose = addMask.getElementsByClassName("close")[0];
        addMask.style.display = "none";
        for(var i = 0; i < addList.length; i++){
            addList[i].onclick = function(){
                for(var j = 0; j < addList.length; j++){
                    addList[j].className= "";
                }
                this.className = "selectBorder";
            }
        }
        for(var i = 0; i < delAdd.length; i++){
            show(delAdd[i],addMask);
            show(addCancel,addMask);
            show(addClose,addMask);
        }
}())*/