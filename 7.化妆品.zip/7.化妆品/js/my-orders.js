$(function(){
    $(".des-title ul").on("click","li",function(){
        $(".des-title ul li").removeClass("fontcolor");
        $(this).addClass("fontcolor");
    })
})