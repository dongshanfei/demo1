$(function(){
    //删除地址
    $(".add-details").on("click","div",function(){
        $(".add-details div").removeClass("selectBorder");
        $(this).addClass("selectBorder");
    })
    $(".add-details").on("click",".del-add",function(){
        $(".del-mask").show();
    })
    $(".del-mask").on("click",".cancel",function(){
        $(".del-mask").hide();
    })
    $(".del-mask").on("click",".close",function(){
        $(".del-mask").hide();
    })  
    $(".del-mask").on("click",".sure",function(){
        $(".selectBorder").remove();
        $(".del-mask").hide();
        layer.alert("删除成功！",{
            icon:1,
            time: 2000,
            anim: 4,
            area: ["400px","150px"],
            btn: false
        })
    })
    //修改地址
    $(".add-details").on("click",".edit",function(){
        console.log($(this));
        $(".edit-mask").show();
        //收货人
        var $textName = $(this).parents("ul").siblings("p").find(".name").text();
        $("#firstname").val($textName);
        //详细地址
        var $textAdd =  $(this).parents("ul").prev().text();
        $("#detail-add").val($textAdd);
        //电话
        var $textTel = $(this).parents("ul").siblings("p").find(".tel").text();
        $("#tel").val($textTel);
    })
    $(".edit-mask").on("click","#cancel",function(){
        $(".edit-mask").hide();
    })
    $(".edit-mask").on("click",".add-close",function(){
        $(".edit-mask").hide();
    })
    //修改地址内容
    $(".edit-mask").on("click","#submit",function(){
        var $name = $("#firstname").val();
        var $userName = $(this).parents(".edit-mask").siblings(".add-details").find(".selectBorder").find(".name");
        $userName.text($name);
        var $tel = $("#tel").val();
        var $userTel = $(this).parents(".edit-mask").siblings(".add-details").find(".selectBorder").find(".tel");
        $userTel.text($tel);
        var $detailAdd = $("#detail-add").val();
        var $userAdd = $(this).parents(".edit-mask").siblings(".add-details").find(".selectBorder").find("h4");
        $userAdd.text($detailAdd);
        $(".edit-mask").hide();
    })
    //点击展开
    $(".click-expansion").on("click",function(){
        $(this).hide();
        $(".click-retract").show();
        // $(".add-ctn").css({
        //     overflow:"visible"
        // })
       
    })
    $(".click-retract").on("click",function(){
        $(this).hide();
        $(".click-expansion").show();
        // $(".add-ctn").css({
        //     overflow:"hidden"
        // })
    })
    // 新增地址
    $(".add-new").on("click",function(){
        $(".add-mask").show();
    })
    $(".add-mask").on("click",".btn-cancel",function(){
        $(".add-mask").hide();
    })
    $(".add-mask").on("click",".close-btn",function(){
        $(".add-mask").hide();
    })
    $(".add-mask").on("click","#btnSaveAddress",function(){
        $(".add-mask").hide();
        var $newAdd = $("<div><p class='contacts'><span class='name fl'>"+$(".add-mask #firstname").val()+"</span><span class='tel fr'>"+$("#telephone").val()+
        "</span></p><h4>"+$("#street").val()+"</h4><ul class='clearfix'><li class='fl'>设为默认地址</li><li class='edit'>修改</li><li class='del-add'>删除</li></ul></div>")
        $newAdd.appendTo($(".add-details"));
        $(".add-mask #firstname").val(" ");
        $("#street").val(" ");
        $("#postcode").val(" ");
        $("#telephone").val(" ");
        $("#email").val(" ");
        layer.alert("新增成功",{
            icon:1,
            time:2000,
            btn: false
        })
    })
    //新增地址表单验证
    var valid=$("#newAddressForm").Validform({
            tiptype:3,
            label:".label",
            showAllError:true,
            datatype:{
                "zh2-4":/^[\u4E00-\u9FA5\uf900-\ufa2d]{2,4}$/,
                "need2":function(gets,obj,curform,regxp){
                    var sel0=curform.find("select").eq(0).val(),
                    sel1=curform.find("select").eq(1).val(),
                    sel2=curform.find("select").eq(2).val();
                    console.log(sel0,sel1,sel2);

                    return  sel0&&sel1&&sel2 ? true : "请选择地区!";
                }
            }
        });
        $.Tipmsg.w={
            "*":"不能为空！",
            "*6-16":"请填写6到16位任意字符！",
            "n":"请填写数字！",
            "n6-16":"请填写6到16位数字！",
            "s":"不能输入特殊字符！",
            "s6-18":"请填写6到18位字符！",
            "p":"请填写邮政编码！",
            "m":"请填写手机号码！",
            "e":"邮箱地址格式不对！",
            "url":"请填写网址！",
            "zh2-4":"请输入2到4个中文字符"
        }
        valid.addRule([{
            ele:"#firstname",
            datatype:"s2-10"
        },{
            ele:"#postcode",
            datatype:"n4-12"
        },{
            ele:"#telephone",
            datatype:"m"
        },{
            ele:"#email",
            datatype:"e"
        },{
            ele:"#street",
            datatype:"*",
            nullmsg:"详细地址不能为空"
        },{
            ele:"#region_id",
            datatype:"need2",
            nullmsg:"请选择地区！"
        },{
            ele:"#city",
            datatype:"need2"
        },{
            ele:"#s_county",
            datatype:"need2"
        }])
})